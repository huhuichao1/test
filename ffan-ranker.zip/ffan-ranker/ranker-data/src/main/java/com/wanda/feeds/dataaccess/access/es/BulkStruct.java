package com.wanda.feeds.dataaccess.access.es;

public class BulkStruct {
	public String method;
	public String indexName;
	public String type;
	public String id;
	public String source;

	static String format = "{ \"%s\" : { \"_index\" : \"%s\", \"_type\" : \"%s\", \"_id\" : \"%s\" } \n %s\n";

	public String toString() {
		return String.format(format, method, indexName, type, id, source);
	}
}
