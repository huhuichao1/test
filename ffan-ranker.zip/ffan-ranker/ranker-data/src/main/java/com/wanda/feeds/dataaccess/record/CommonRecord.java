package com.wanda.feeds.dataaccess.record;

import org.elasticsearch.common.xcontent.XContentBuilder;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.base.RecordBase;

public class CommonRecord extends RecordBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String data;

	public XContentBuilder biuld(XContentBuilder jsonBuild) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RecordBase build(JSONObject hit) {
		// TODO Auto-generated method stub
		CommonRecord ret = new CommonRecord();
		ret.setData(hit.toString());
		return ret;
	}

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
