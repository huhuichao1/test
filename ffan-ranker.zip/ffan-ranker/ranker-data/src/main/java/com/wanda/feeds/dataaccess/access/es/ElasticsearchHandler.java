package com.wanda.feeds.dataaccess.access.es;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.dataaccess.access.base.IAccessHandler;
import com.wanda.feeds.dataaccess.access.base.SearchResult;
import com.wanda.feeds.dataaccess.utils.CharUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.client.Response;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.sort.SortBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class ElasticsearchHandler implements IAccessHandler {

	public static int pageSize = 10000;

	ElasticsearchClient esClient;

	Logger logger = Logger.getLogger(ElasticsearchHandler.class);

	
	public void closeEsClient(){
		esClient.closeClient();
	}
	/**
	 * 
	 * @param prop
	 */
	public ElasticsearchHandler(Properties prop) {
		esClient = new ElasticsearchClient();
		esClient.init(prop);
	}

	public static class IndexStruct {
		public String id;
		public String json;
	}

	/**
	 * 
	 * @param indexname
	 * @param type
	 * @param data
	 * @return
	 */

	public BulkResponse createIndexResponse(String indexname, String type, List<IndexStruct> data) {
		Response response = null;
		BulkResponse bulkResponse = null;
		StringBuilder bulkIndexRequest = new StringBuilder();
		for (IndexStruct str : data) {
			BulkStruct bs = new BulkStruct();
			bs.id = str.id;
			bs.indexName = indexname;
			bs.method = "index";
			bs.type = type;
			bs.source = str.json;
			bulkIndexRequest.append(bs.toString());
		}

		StringEntity entity = new StringEntity(bulkIndexRequest.toString(), Charset.defaultCharset());
		long beginTime = System.currentTimeMillis();
		try {
			response = esClient.restClient.performRequest("POST", "/_bulk", Collections.<String, String> emptyMap(),
					entity);
			String resEntity = EntityUtils.toString(response.getEntity());
			if (resEntity.contains("\"errors\":true")) {
				System.out.println(resEntity);
			}
			if (resEntity.contains("\"errors\":false")) {
				System.out.println("====success=====");
			}
			// System.out.println(resEntity);
			bulkResponse = (BulkResponse) JSONObject.toJavaObject(JSONObject.parseObject(resEntity),
					BulkResponse.class);

			logger.info("=====insert index====\n" + resEntity);

		} catch (IOException e) {
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		logger.info("=====insert index=====耗时: " + (endTime - beginTime) + "ms");
		System.out.println("=====insert index=====耗时: " + (endTime - beginTime) + "ms");
		return bulkResponse;
	}

	/**
	 * 
	 * @author syp
	 *
	 */
	public static class HitsStruct {
		public int count;
		public List<RecordBase> records = new ArrayList<RecordBase>();
	}

	/**
	 * 
	 * @param queryBuilder
	 * @param indexname
	 * @param type
	 * @return
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	public SearchResult searchByRustfulScroll(QueryBuilder queryBuilder, String indexname, String type, int start,
											  int size, SortBuilder order, Class<? extends RecordBase> T, SQLCallback callback, String sourceFileds)
			throws UnsupportedEncodingException, IOException {

		// List<RecordBase> list = new ArrayList<RecordBase>();
		int finishCount = 0;
		SearchResult result = new SearchResult();

		String scrollID = null;
//		logger.info(queryBuilder.toString());
		List<RecordBase> searchResponse = new ArrayList<RecordBase>();
		String httpURL = "/";
		if (indexname != null) {
			httpURL += indexname + "/";
		}
		if (type != null) {
			httpURL += type + "/";
		}
		// Random rand = new Random();
		httpURL += "_search?scroll=5m" + sourceFileds;

		System.out.println("=====httpURL=" + httpURL);
		SearchRequestBuilder builder = esClient.client.prepareSearch(indexname).setQuery(queryBuilder);
		if (size > pageSize) {
			builder.setSize(pageSize);
			finishCount = pageSize;
		} else {
			builder.setSize(size);
			finishCount = size;
		}
		if (start > 0) {
			builder.setFrom(start);
		}
		if (type != null) {
			builder.setTypes(type);
		}
		if (order != null) {

			builder.addSort(order);

		}
		try {
			String querys = rebuildQuery(builder.toString());
			logger.info(querys);
//			System.out.println(querys);
			long satrt = System.currentTimeMillis();
			Response indexResponse = this.esClient.restClient.performRequest("POST", httpURL,
					Collections.singletonMap("pretty", "true"), new NStringEntity(querys));
			// indexResponse.get
//			System.out.println("=======indexResponse 耗时=====" + (System.currentTimeMillis() - satrt));
			InputStream storm = indexResponse.getEntity().getContent();
//			System.out.println("=======getEntity 耗时=====" + (System.currentTimeMillis() - satrt));
//			satrt = System.currentTimeMillis();
			String buildQuery = CharUtils.convertStreamToString(storm);
//			System.out.println("=======convertStreamToString 耗时=====" + (System.currentTimeMillis() - satrt));
//			satrt = System.currentTimeMillis();
			// System.out.println(buildQuery.trim());

			// JSONObject obj = JSONObject.fromObject(buildQuery.trim());

			JSONObject obj = JSONObject.parseObject(buildQuery.trim());
			// JsonParser parser = new JsonParser();
			// JsonElement jsonEl = parser.parse(buildQuery.trim());
			// JsonObject obj1 = jsonEl.getAsJsonObject();
			scrollID = (String) obj.get("_scroll_id");
			JSONObject jsonObj = obj.getJSONObject("hits");
			if (jsonObj != null) {
				// JsonObject jsonArray = obj1.getAsJsonObject("hits");
				HitsStruct hits = this.parserHits(jsonObj, T, callback);
				logger.info("检查到新增数据集为："+hits.count+"条。。scrollID="+scrollID);
				result.setHitCount(hits.count);
				searchResponse.addAll(hits.records);
			}

//			System.out.println("=======fromObject 耗时=====" + (System.currentTimeMillis() - satrt));

//			satrt = System.currentTimeMillis();
			while (finishCount < size && finishCount < result.getHitCount()) {
//				long start1 = System.currentTimeMillis();
				// String entity = "{\n\"scroll_id\": \"" + scrollID +
				// "\"\n,\n\"scroll\": \"5m\"}";
				String entity = "{}";
//				System.out.println(entity);

				Response response = this.esClient.restClient.performRequest("GET",
						"/_search/scroll?scroll=5m&", Collections.singletonMap("scroll_id", scrollID),
						new NStringEntity(entity));

				buildQuery = CharUtils.convertStreamToString(response.getEntity().getContent()).trim();
				// jsonEl = parser.parse(buildQuery.trim());
				// obj1 = jsonEl.getAsJsonObject();
				obj = JSONObject.parseObject(buildQuery.trim());
//				System.out.println(obj.get("_scroll_id").toString());
				if (obj.getJSONObject("hits") != null) {
					JSONObject jsonArray = obj.getJSONObject("hits");
					HitsStruct hits = this.parserHits(jsonArray, T, callback);
//					System.out.println(hits.count);
					// result.setHitCount(hits.count);
					searchResponse.addAll(hits.records);
				}

				finishCount += pageSize;
//				System.out.println("====已经完成解析=====" + finishCount + "用时=" + (System.currentTimeMillis() - start1));
			}
			logger.info("execute success！ explain" + finishCount + " ，cost：" + (System.currentTimeMillis() - satrt)/1000+"s...");
			result.setRecord(searchResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
		// searchResponse = builder.execute().actionGet();

		// return searchResponse;

	}

	/**
	 * 
	 * @param hits
	 * @param T
	 * @return
	 */
	private HitsStruct parserHits(JSONObject hits, Class<? extends RecordBase> T) {
		HitsStruct hit = new HitsStruct();

		if (hits.get("total") != null) {
			hit.count = (Integer) hits.get("total");
		}
		if (hits.get("hits") != null) {
			JSONArray array = hits.getJSONArray("hits");
			for (int index = 0; index < array.size(); index++) {
				// System.out.println(b);
				long start = System.currentTimeMillis();
				JSONObject record = array.getJSONObject(index);
				if (record.get("_source") != null && !record.getJSONObject("_source").containsKey("scroll_id")) {
					JSONObject source = record.getJSONObject("_source");
					RecordBase dRecord = null;
					try {
						Method method = T.getMethod("build", JSONObject.class);
						Object o = T.newInstance();
						// JSONObject json = JSONObject.fromObject(source);
						dRecord = (RecordBase) method.invoke(o, source);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					hit.records.add(dRecord);
				}

			}
		}
		return hit;
	}

	/**
	 * 
	 * @param hits
	 * @param T
	 * @param callback
	 * @return
	 */
	private HitsStruct parserHits(JSONObject hits, Class<? extends RecordBase> T, SQLCallback callback) {
		HitsStruct hit = new HitsStruct();
		if (hits.get("total") != null) {
			hit.count = (Integer) hits.get("total");
		}
		long start = System.currentTimeMillis();
		if (hits.get("hits") != null) {
			JSONArray array = hits.getJSONArray("hits");
			for (int index = 0; index < array.size(); index++) {
				// System.out.println(b);

				JSONObject record = array.getJSONObject(index);
				if (record.get("_source") != null) {
					JSONObject source = record.getJSONObject("_source");
					RecordBase dRecord = null;
					try {
						Method method = T.getMethod("build", JSONObject.class);
						Object o = T.newInstance();
						dRecord = (RecordBase) method.invoke(o, source);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (callback != null) {
						RecordBase buff = (RecordBase) callback.callback(dRecord);
						if (buff != null) {
							dRecord = buff;
						}
					}
					hit.records.add(dRecord);
				}
			}

		}

//		System.out.println("单条解析用时=" + (System.currentTimeMillis() - start));

		return hit;
	}

	/**
	 * 重写query
	 * 
	 * @param queryString
	 * @return
	 */
	public String rebuildQuery(String queryString) {

		String[] list = queryString.split("\"exists\"");
		String ret = list[0];
		for (int idx = 1; idx < list.length; idx++) {
			ret += "\"exists\":";
			if (list[idx] != null) {
				int start = list[idx].indexOf("{");
				int end = list[idx].indexOf("}");
				ret += list[idx].substring(start, end).replace(",", "").replace("\"boost\" : 1.0", "");
				ret += list[idx].substring(end);
			}
		}

		ret = ret.replace("\"min_doc_count\" : 1", "\"min_doc_count\" : 1");
		ret = ret.replace("\"_count\" : \"desc\"", "\"_count\" : \"asc\"");

		return ret;

	}

	/**
	 * 
	 * @param queryBuilder
	 * @param indexname
	 * @param type
	 * @return
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	public SearchResult searchScrollUpsert(QueryBuilder queryBuilder, String indexname, String type, int start,
			int size, SortBuilder order, Class<? extends RecordBase> T, SQLCallback sqlCallback)
			throws UnsupportedEncodingException, IOException {

		// List<RecordBase> list = new ArrayList<RecordBase>();
		int finishCount = 0;
		SearchResult result = new SearchResult();

		String scrollID = null;
		logger.info(queryBuilder.toString());
		List<RecordBase> searchResponse = new ArrayList<RecordBase>();
		String httpURL = "/";
		if (indexname != null) {
			httpURL += indexname + "/";
		}
		if (type != null) {
			httpURL += type + "/";
		}
		httpURL += "_search?scroll=5m";

		SearchRequestBuilder builder = esClient.client.prepareSearch(indexname).setQuery(queryBuilder);
		if (size > pageSize) {
			builder.setSize(pageSize);
			finishCount = pageSize;
		} else {
			builder.setSize(size);
			finishCount = size;
		}
		if (start > 0) {
			builder.setFrom(start);
		}
		if (type != null) {
			builder.setTypes(type);
		}
		if (order != null) {

			builder.addSort(order);

		}
		try {
			String querys = rebuildQuery(builder.toString());

			System.out.println(querys);
			long satrt = System.currentTimeMillis();
			System.out.println();
			Response indexResponse = this.esClient.restClient.performRequest("POST", httpURL,
					Collections.singletonMap("pretty", "true"), new NStringEntity(querys));
			// indexResponse.get
			System.out.println("=======indexResponse 耗时=====" + (System.currentTimeMillis() - satrt));
			InputStream storm = indexResponse.getEntity().getContent();
			System.out.println("=======getEntity 耗时=====" + (System.currentTimeMillis() - satrt));
			satrt = System.currentTimeMillis();
			String buildQuery = CharUtils.convertStreamToString(storm);
			System.out.println("=======convertStreamToString 耗时=====" + (System.currentTimeMillis() - satrt));
			satrt = System.currentTimeMillis();
			// System.out.println(buildQuery.trim());

			JSONObject obj = JSONObject.parseObject(buildQuery.trim());
			// JsonParser parser = new JsonParser();
			// JsonElement jsonEl = parser.parse(buildQuery.trim());
			// JsonObject obj1 = jsonEl.getAsJsonObject();
			scrollID = obj.get("_scroll_id").toString();

			// _scroll_id
			System.out.println(obj.get("_scroll_id").toString());
			if (obj.getJSONObject("hits") != null) {
				JSONObject jsonArray = obj.getJSONObject("hits");
				HitsStruct hits = this.parserHits(jsonArray, T, sqlCallback);
				System.out.println(hits.count);
				result.setHitCount(hits.count);
				searchResponse.addAll(hits.records);
			}

			System.out.println("=======fromObject 耗时=====" + (System.currentTimeMillis() - satrt));

			satrt = System.currentTimeMillis();
			while (finishCount < size && finishCount < result.getHitCount()) {
				long start1 = System.currentTimeMillis();
				Response response = this.esClient.restClient.performRequest("POST", "/_search/scroll",
						Collections.singletonMap("pretty", "true"),
						new NStringEntity("{\n\"scroll\": \"40m\",\n\"scroll_id\": \"" + scrollID + "\"\n}"));

				buildQuery = CharUtils.convertStreamToString(response.getEntity().getContent()).trim();
				// jsonEl = parser.parse(buildQuery.trim());
				// obj1 = jsonEl.getAsJsonObject();
				obj = JSONObject.parseObject(buildQuery.trim());
				System.out.println(obj.get("_scroll_id").toString());
				if (obj.getJSONObject("hits") != null) {
					JSONObject jsonArray = obj.getJSONObject("hits");
					HitsStruct hits = this.parserHits(jsonArray, T, sqlCallback);
					System.out.println(hits.count);
					// result.setHitCount(hits.count);
					// searchResponse.addAll(hits.records);
				}

				finishCount += pageSize;
				System.out.println("====已经完成解析=====" + finishCount + "用时=" + (System.currentTimeMillis() - start1));
			}
			long end = System.currentTimeMillis();
			System.out.println("====已经完成解析=====" + finishCount + "用时=" + (end - start));

			if (searchResponse.size() > 1000) {
				result.setRecord(searchResponse.subList(0, 1000));
			} else {
				result.setRecord(searchResponse);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 
	 * @param queryBuilder
	 * @param indexname
	 * @param type
	 * @return
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	public SearchResult searchByRest(QueryBuilder queryBuilder, String indexname, String type, int start, int size,
			SortBuilder order, Class<? extends RecordBase> T) throws UnsupportedEncodingException, IOException {

		// List<RecordBase> list = new ArrayList<RecordBase>();
		int finishCount = 0;
		SearchResult result = new SearchResult();

		// String scrollID = null;
		logger.info(queryBuilder.toString());
		List<RecordBase> searchResponse = new ArrayList<RecordBase>();
		String httpURL = "/";
		if (indexname != null) {
			httpURL += indexname + "/";
		}
		if (type != null) {
			httpURL += type + "/";
		}
		httpURL += "_search";

		SearchRequestBuilder builder = esClient.client.prepareSearch(indexname).setQuery(queryBuilder);
		if (size > pageSize) {
			builder.setSize(pageSize);
			finishCount = pageSize;
		} else {
			builder.setSize(size);
			finishCount = size;
		}
		if (start > 0) {
			builder.setFrom(start);
		}
		if (type != null) {
			builder.setTypes(type);
		}
		if (order != null) {

			builder.addSort(order);

		}
		try {
			String querys = rebuildQuery(builder.toString());

			System.out.println(querys);
			long satrt = System.currentTimeMillis();
			System.out.println();
			Response indexResponse = this.esClient.restClient.performRequest("POST", httpURL,
					Collections.singletonMap("pretty", "true"), new NStringEntity(querys));
			// indexResponse.get
			System.out.println(httpURL + "=======indexResponse 耗时=====" + (System.currentTimeMillis() - satrt));
			InputStream storm = indexResponse.getEntity().getContent();
			System.out.println("=======getEntity 耗时=====" + (System.currentTimeMillis() - satrt));
			satrt = System.currentTimeMillis();
			String buildQuery = CharUtils.convertStreamToString(storm);
			System.out.println("=======convertStreamToString 耗时=====" + (System.currentTimeMillis() - satrt));
			satrt = System.currentTimeMillis();
			// System.out.println(buildQuery.trim());

			JSONObject obj = JSONObject.parseObject(buildQuery.trim());
			// JsonParser parser = new JsonParser();
			// JsonElement jsonEl = parser.parse(buildQuery.trim());
			// JSONObject obj1 = jsonEl.getAsJsonObject();
			if (obj.getJSONObject("hits") != null) {
				JSONObject jsonArray = obj.getJSONObject("hits");
				HitsStruct hits = this.parserHits(jsonArray, T);
				System.out.println(hits.count);
				result.setHitCount(hits.count);
				searchResponse.addAll(hits.records);
			}

			System.out.println("=======fromObject 耗时=====" + (System.currentTimeMillis() - satrt));

			satrt = System.currentTimeMillis();
			while (finishCount < size && finishCount < result.getHitCount()) {
				long start1 = System.currentTimeMillis();
				// String entity = "{\n\"scroll_id\": \"" + scrollID +
				// "\"\n,\n\"scroll\": \"5m\"}";
				// String entity = "{}";
				// System.out.println(entity);

				builder.setFrom(finishCount);

				Response response = this.esClient.restClient.performRequest("GET", httpURL,
						Collections.singletonMap("pretty", "true"),
						new NStringEntity(rebuildQuery(builder.toString())));
				System.out.println(rebuildQuery(builder.toString()));

				buildQuery = CharUtils.convertStreamToString(response.getEntity().getContent()).trim();
				obj = JSONObject.parseObject(buildQuery.trim());
				// System.out.println(obj1.get("_scroll_id").getAsString());
				if (obj.getJSONObject("hits") != null) {
					JSONObject jsonArray = obj.getJSONObject("hits");
					HitsStruct hits = this.parserHits(jsonArray, T);
					System.out.println(hits.count);
					// result.setHitCount(hits.count);
					searchResponse.addAll(hits.records);
				}

				finishCount += pageSize;
				System.out.println("====已经完成解析=====" + finishCount + "用时=" + (System.currentTimeMillis() - start1));
			}
			long end = System.currentTimeMillis();
			System.out.println("====已经完成解析=====" + finishCount + "用时=" + (end - start));

			result.setRecord(searchResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}
}
