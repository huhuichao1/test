package com.wanda.feeds.dataaccess.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

/**
 * 字符处理工具类
 * 
 * @author Feng Ji
 * 
 */
public class CharUtils {
	// 区号表
	public static HashMap<String, String> AREA_CODE_TABLE = null;

	// 拼音表
	public static HashSet<String> PINYIN_SET = null;
	public static HashSet<String> NOT_TAIL_SET = null;

	public static HashSet<String> COMBINATOR_SET = null;
	public static String[] NOT_TAILS = new String[] { "b", "c", "d", "f", "h",
			"j", "k", "l", "m", "p", "q", "r", "s", "t", "w", "x", "y", "z" };

	public static String[] COMBINATORS = new String[] { "a", "ai", "an", "ang",
			"ao", "e", "ei", "en", "eng", "o", "ou" };

	private static HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();

	/**
	 * 全角转半角
	 * 
	 * @param input
	 *            全角字符串
	 * @return 半角字符串
	 */
	public static String toDBC(String input) {
		char[] c = input.toCharArray();
		for (int i = 0; i < c.length; i++) {
			if (c[i] == 12288) {
				c[i] = (char) 32;
				continue;
			}
			if (c[i] > 65280 && c[i] < 65375)
				c[i] = (char) (c[i] - 65248);
		}
		return new String(c);
	}

	/**
	 * 半角转全角
	 * 
	 * @param input
	 *            半角字符串
	 * @return 全角字符串
	 */
	public static String toSBC(String input) {
		char[] c = input.toCharArray();
		for (int i = 0; i < c.length; i++) {
			if (c[i] == 32) {
				c[i] = (char) 12288;
				continue;
			}
			if (c[i] < 127)
				c[i] = (char) (c[i] + 65248);
		}
		return new String(c);
	}

	public static boolean replaceContain(String dst, String org, char split) {
		if (dst == null || org == null || dst.length() != org.length()) {
			return false;
		}
		int count = dst.length();
		for (int i = 0; i < count; i++) {
			if (dst.charAt(i) == split || dst.charAt(i) == org.charAt(i)) {
				continue;
			} else {
				return false;
			}
		}
		return true;
	}

	public static String getSuffix(String org, String dst, int len) {
		if (dst == null || org == null || len == 0) {
			return null;
		}
		int idx = org.indexOf(dst);
		if (idx < 0) {
			return null;
		}
		if (idx + dst.length() + len > org.length()) {
			len = org.length() - (idx + dst.length());
		}
		return org.substring(idx + dst.length(), idx + dst.length() + len);
	}

	/**
	 * toPinyin
	 * 
	 * @param input
	 * @param split
	 * @return
	 */
	public static String toPinyin(String input, String split) {
		String ret = null;
		if (input == null) {
			return ret;
		}
		HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
		format.setVCharType(HanyuPinyinVCharType.WITH_U_AND_COLON);
		format.setCaseType(HanyuPinyinCaseType.UPPERCASE);
		format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);

		try {
			ret = PinyinHelper.toHanyuPinyinString(input, format, split);
		} catch (BadHanyuPinyinOutputFormatCombination e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return ret;
		}
		return ret;
	}

	/**
	 * 汉字字符串转换为拼音
	 * 
	 * @param input
	 *            汉字字符串
	 * @return 拼音字符串
	 */
	@SuppressWarnings("rawtypes")
	public static List[] toPinyin(String input) {
		// 去除括号的内容
		String processedstr = toDBC(input).replaceAll("[(].*[)]", "");

		// 取出特殊符号和数字
		processedstr = processedstr.replaceAll("\\d*-*_*\\s*", "");

		char[] charry = processedstr.toCharArray();

		ArrayList<ArrayList<String>> pinyinarray = new ArrayList<ArrayList<String>>();
		HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();

		format.setVCharType(HanyuPinyinVCharType.WITH_U_AND_COLON);
		format.setCaseType(HanyuPinyinCaseType.UPPERCASE);
		format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);

		for (int i = 0; i < charry.length; i++) {
			ArrayList<String> pinyinlist = new ArrayList<String>();
			if (isEnglishChar(charry[i])) {
				pinyinlist.add(String.valueOf(charry[i]));
				pinyinarray.add(pinyinlist);
			} else {
				try {
					String[] pinyins = PinyinHelper.toHanyuPinyinStringArray(
							charry[i], format);
					if (pinyins != null) {
						for (String strpinyin : pinyins) {
							// 删除所有的":"
							pinyinlist.add(strpinyin.replaceAll(":", ""));
						}
						pinyinarray.add(pinyinlist);
					} else {
						pinyinarray.add(pinyinlist);
					}
				} catch (BadHanyuPinyinOutputFormatCombination e) {
					e.printStackTrace();
				}
			}
		}
		return pinyinarray.toArray(new List[pinyinarray.size()]);
	}

	public static String chineseToPinyin(String chs) {
		StringBuffer pybuf = new StringBuffer();
		for (int i = 0; i < chs.length(); i++) {
			char cur = chs.charAt(i);
			if (cur > 128) {
				try {
					String[] _t = PinyinHelper.toHanyuPinyinStringArray(cur,
							format);
					if (_t != null) {
						char[] _chs = _t[0].toCharArray();
						_chs[0] = (char) (_chs[0] + 'A' - 'a');
						pybuf.append(_chs);
					}
				} catch (BadHanyuPinyinOutputFormatCombination e) {
					e.printStackTrace();
				}
			} else {
				pybuf.append(cur);
			}
		}
		return pybuf.toString().trim();
	}

	public static String replaceBrackets(String input) {
		// Bracket's count
		if (input.contains("(") || input.contains(")")) {
			int bracket = input.indexOf('(');
			int end_bracket = input.indexOf(')');
			if (end_bracket >= bracket) {
				String temp = "";
				if (bracket != -1)
					temp = input.substring(0, bracket);
				if (end_bracket < input.length() && end_bracket != -1) {
					temp += input.substring(end_bracket + 1, input.length());
				}
				input = replaceBrackets(temp);
			} else {
				String temp = "";
				if (end_bracket != -1)
					temp = input.substring(0, end_bracket);
				if (bracket < input.length() && bracket != -1) {
					temp += input.substring(bracket + 1, input.length());
				}
				input = replaceBrackets(temp);
			}

		}
		return input;
	}

	public static boolean isEnglishChar(char c) {
		if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
			return true;
		else
			return false;
	}
	
	
	public static String convertStreamToString(InputStream is) {      
        /*  
          * To convert the InputStream to String we use the BufferedReader.readLine()  
          * method. We iterate until the BufferedReader return null which means  
          * there's no more data to read. Each line will appended to a StringBuilder  
          * and returned as String.  
          */     
         BufferedReader reader = new BufferedReader(new InputStreamReader(is));      
         StringBuilder sb = new StringBuilder();      
     
         String line = null;      
        try {      
            while ((line = reader.readLine()) != null) {      
                 sb.append(line + " ");      
             }      
         } catch (IOException e) {      
             e.printStackTrace();      
         } finally {      
            try {      
                 is.close();      
             } catch (IOException e) {      
                 e.printStackTrace();      
             }      
         }      
     
        return sb.toString();      
     }
}
