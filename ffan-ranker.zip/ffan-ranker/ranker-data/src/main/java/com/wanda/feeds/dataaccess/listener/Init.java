package com.wanda.feeds.dataaccess.listener;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class Init{
	public static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	// public static ThreadPoolTaskExecutor threadPool;

	public static Properties esProp;

	static {
		init();
	}

	public static void init() {
		
//		@SuppressWarnings("resource")
//		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:application.xml");
		// threadPool = (ThreadPoolTaskExecutor)
		// context.getBean("taskExecutor");
		esProp = new Properties();
		try {
			InputStream inStream = Init.class.getClassLoader().getResourceAsStream("elasticsearch.properties");
			esProp.load(inStream);// 将属性文件流装载到Properties对象中

			System.out.println("=================初始化完成=================");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.exit(1);
			System.out.println("init error");
			e.printStackTrace();
		}
	}

	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

	public void contextInitialized(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("------------Server started!-------------------");

	}
}
