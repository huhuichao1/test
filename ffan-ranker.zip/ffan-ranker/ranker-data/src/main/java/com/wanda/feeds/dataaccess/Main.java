package com.wanda.feeds.dataaccess;

import com.wanda.feeds.common.utils.io.FileOperater;
import com.wanda.feeds.common.utils.io.MyCallBack;

public class Main {

	public static void main(String[] args) {
		MyCallBack call = new MyCallBack(){

			@Override
			public void operation(String string, Object object) {
				// TODO Auto-generated method stub
				FileOperater.write("/Users/syp/Documents/tmp/LDA/jgibbLda/onlinedata-1016.txt", string);
			}};
			FileOperater.write("/Users/syp/Documents/tmp/LDA/jgibbLda/onlinedata-1016.txt", "474980");
			FileOperater.readline("/Users/syp/Documents/tmp/LDA/jgibbLda/onlinedata-1016.txt",call);
		
		
	}
}
