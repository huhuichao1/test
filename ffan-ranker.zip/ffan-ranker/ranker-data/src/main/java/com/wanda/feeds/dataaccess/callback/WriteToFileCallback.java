package com.wanda.feeds.dataaccess.callback;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.doc.Article;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.common.utils.io.FileOperater;
import com.wanda.feeds.common.utils.json.JsonUtil;
import com.wanda.feeds.dataaccess.record.DocumentRecord;

import java.util.List;

public class WriteToFileCallback implements SQLCallback {

    String content_full_path = "/tmp/article_info.txt";


    public Object callback(RecordBase entity) {
        DocumentRecord record=(DocumentRecord)entity;
//        DataCleanFormateDocument cleandoc = (DataCleanFormateDocument) entity;
        FileOperater.write(content_full_path, record.getId());

        return null;
    }


    public String getContent_full_path() {
        return content_full_path;
    }

    public void setContent_full_path(String content_full_path) {
        this.content_full_path = content_full_path;
    }



    public static class DataCleanFormateDocument  extends RecordBase{
        private String id;
        private Article article;
        private List<String> categoryIds;


        public static DataCleanFormateDocument fromJson(String json) {
            return (DataCleanFormateDocument) JsonUtil.parseObject(json, DataCleanFormateDocument.class);
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }


        @Override
        public RecordBase build(JSONObject hit) {
            DataCleanFormateDocument data=new DataCleanFormateDocument();
            data.id = hit.getString("id");
//            Article article=hit.getObject("article",Article.class);
//            article=JSONObject.parseObject(hit.getString("article"), Article.class);
//            data.article=JSONObject.toJavaObject(hit.getJSONObject("article"),Article.class);
            data.article=hit.getObject("article",Article.class);
            List<String> array= JSONArray.parseArray(hit.getString("categoryIds"),String.class);
            data.categoryIds=array;
            return data;
        }



        @Override
        public String toString() {
            return JSONObject.toJSONString(this);
        }

        public List<String> getCategoryIds() {
            return categoryIds;
        }

        public void setCategoryIds(List<String> categoryIds) {
            this.categoryIds = categoryIds;
        }

        public Article getArticle() {
            return article;
        }

        public void setArticle(Article article) {
            this.article = article;
        }
    }

}
