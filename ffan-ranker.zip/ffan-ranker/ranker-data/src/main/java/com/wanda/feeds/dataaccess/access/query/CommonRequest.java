package com.wanda.feeds.dataaccess.access.query;


import com.wanda.feeds.common.entity.base.RequestBase;

import java.util.List;



public class CommonRequest extends RequestBase {

	private List<String> sourcefeilds;

	public List<String> getSourcefeilds() {
		return sourcefeilds;
	}

	public void setSourcefeilds(List<String> sourcefeilds) {
		this.sourcefeilds = sourcefeilds;
	}

	private List<String> hasFields;

	public List<String> getHasFields() {
		return hasFields;
	}

	public void setHasFields(List<String> hasFields) {
		this.hasFields = hasFields;
	}
}
