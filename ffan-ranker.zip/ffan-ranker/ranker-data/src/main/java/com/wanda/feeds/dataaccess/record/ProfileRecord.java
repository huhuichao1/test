package com.wanda.feeds.dataaccess.record;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.common.entity.base.RecordBase;

import java.util.List;


/**
 * Created by huhuichao on 2017/9/7.
 */
public class ProfileRecord extends RecordBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public List<KeyValuePair> getTopic64Preference() {
		return topic64Preference;
	}

	public void setTopic64Preference(List<KeyValuePair> topic64Preference) {
		this.topic64Preference = topic64Preference;
	}

	public List<KeyValuePair> getCategoryPreference() {
		return categoryPreference;
	}

	public void setCategoryPreference(List<KeyValuePair> categoryPreference) {
		this.categoryPreference = categoryPreference;
	}

	public List<KeyValuePair> getKeywordPreference() {
		return keywordPreference;
	}

	public void setKeywordPreference(List<KeyValuePair> keywordPreference) {
		this.keywordPreference = keywordPreference;
	}

	public String getTargetCity() {
		return targetCity;
	}

	public void setTargetCity(String targetCity) {
		this.targetCity = targetCity;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getGender() {
		return gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	private List<KeyValuePair> categoryPreference; // category特征信息
	private List<KeyValuePair> keywordPreference; // keyword特征信息
	private List<KeyValuePair> topic64Preference; // topic特征信息

	private String targetCity;
	private String userId;
	private Integer gender;
	private Integer age;

	public UserProfile parse() {
		UserProfile ret = new UserProfile();
		ret.setUserId(userId);
		ret.setKeywordPreference(this.categoryPreference);
		ret.setTopic64Preference(this.topic64Preference);
		ret.setKeywordPreference(this.keywordPreference);
		ret.setTargetCity(targetCity);
		ret.setAge(age);
		ret.setGender(gender);

		return ret;

	}

	@Override
	public RecordBase build(JSONObject hit) {
		return JSONObject.toJavaObject(hit, ProfileRecord.class);

		// return null;
	}
}
