package com.wanda.feeds.dataaccess.access.base;

import com.wanda.feeds.common.entity.base.RecordBase;
import org.elasticsearch.action.search.SearchResponse;





public interface IDataAccessResult {
	public IDataAccessResult build(SearchResponse response, Class<? extends RecordBase> T);
}
