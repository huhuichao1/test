package com.wanda.feeds.dataaccess.service;

import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.entity.base.RequestBase.QueryStruct;
import com.wanda.feeds.common.entity.base.RequestBase.Relationship;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.dataaccess.access.FeedsAccess;
import com.wanda.feeds.dataaccess.access.base.SearchResult;
import com.wanda.feeds.dataaccess.access.es.ElasticsearchHandler;
import com.wanda.feeds.dataaccess.access.query.FeedsRequest;
import com.wanda.feeds.dataaccess.callback.WriteToFileCallback;
import com.wanda.feeds.dataaccess.listener.Init;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import org.apache.log4j.Logger;

import java.util.*;

public class NdcgDocumentAccessService implements AccessService {

	static Logger logger = Logger.getLogger(NdcgDocumentAccessService.class);
	static final int maxSize = 200;
	static final String indexName = "ndcg-doc";
	static final int ALL_COUNT = 10000000;
	FeedsAccess access = new FeedsAccess();

	public NdcgDocumentAccessService(Properties prop) {
		access = new FeedsAccess();
		access.handler = new ElasticsearchHandler(prop);
	}

	public NdcgDocumentAccessService() {
		access = new FeedsAccess();
		if (Init.esProp == null) {
			Init.init();
		}
		access.handler = new ElasticsearchHandler(Init.esProp);
	}

	public void closeAccess() {
		if (access != null) {
			access.closeHander();
		}
	}


	public List<RecordBase>  getAllRecordes(SQLCallback callback, int count) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(count);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("isPremium");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("subType");
		sourceFields.add("consumeScore");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;

		try {
			sResult = access.select(req, DocumentRecord.class, callback);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		return sResult.getRecord();

	}

	public DocumentRecord getRecordById(String id) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(1);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("isPremium");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("subType");
		sourceFields.add("consumeScore");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;
		Map<String, QueryStruct> queryStruct = new HashMap<String, QueryStruct>();
		QueryStruct qs = new QueryStruct();
		qs.keyword = id;
		qs.relation = Relationship.term;
		queryStruct.put("id", qs);
		req.setFreeQuery(queryStruct);
		try {
			sResult = access.select(req, DocumentRecord.class, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		if (sResult == null || sResult.getHitCount() == 0) {
			return null;
		}
		return (DocumentRecord) sResult.getRecord().get(0);
	}

	public static void main(String[] args) {

		NdcgDocumentAccessService service = new NdcgDocumentAccessService();
		List<RecordBase> list = service.getAllRecordes(new WriteToFileCallback(), 50000);
		ElasticsearchHandler h = (ElasticsearchHandler) service.access.handler;
		h.closeEsClient();
		System.out.println("输出集合总数:" + list.size());

		// // InitListener
		// FeedsRequest req = new FeedsRequest();
		// req.setIndexname("feeds");
		// req.setSize(100);
		// req.setStart(0);
		// FeedsAccess access = new FeedsAccess();
		// access.handler = new ElasticsearchHandler(Init.esProp);
		// // req.setSort(sort);
		// // Result<List<ModelResult>> result = Result.okResult();
		//
		// SearchResult res = access.select(req, DocumentRecord.class);
		// System.out.println(JSONObject.toJSONString(res));
	}


	@Override
	public List<RecordBase> getSimRecords(DocumentRecord doc) throws Exception {
		return null;
	}
}
