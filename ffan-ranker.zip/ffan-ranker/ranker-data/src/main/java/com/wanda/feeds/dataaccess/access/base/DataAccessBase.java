package com.wanda.feeds.dataaccess.access.base;


import com.wanda.feeds.common.utils.callback.SQLCallback;

import java.util.List;


public abstract class DataAccessBase implements IDataAccess {
	private DATA_ACCESS_TYPE type;
	public IAccessHandler handler;
	private SQLCallback esSQLCallback;

	public DataAccessBase(DATA_ACCESS_TYPE type) {
		this.setType(type);
	}

	public DATA_ACCESS_TYPE getType() {
		return type;
	}

	public void setType(DATA_ACCESS_TYPE type) {
		this.type = type;
	}

	public SQLCallback getEsSQLCallback() {
		return esSQLCallback;
	}

	public void setEsSQLCallback(SQLCallback esSQLCallback) {
		this.esSQLCallback = esSQLCallback;
	}

	protected String getSourceFileds(List<String> strs) {
		if (strs == null || strs.size() == 0) {
			return "";
		}
		String ret = "&_source=";
		for (String str : strs) {
			ret += str;
			ret += ",";
		}
		return ret.substring(0, ret.length() - 1);
	}

}
