package com.wanda.feeds.dataaccess.service;


import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.entity.base.RequestBase;
import com.wanda.feeds.common.entity.base.RequestBase.*;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.dataaccess.access.FeedsAccess;
import com.wanda.feeds.dataaccess.access.base.SearchResult;
import com.wanda.feeds.dataaccess.access.es.ElasticsearchHandler;
import com.wanda.feeds.dataaccess.access.query.FeedsRequest;
import com.wanda.feeds.dataaccess.callback.WriteToFileCallback;
import com.wanda.feeds.dataaccess.listener.Init;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import org.apache.log4j.Logger;

import java.util.*;

public class FeedsAccessService implements AccessService {

	static Logger logger = Logger.getLogger(FeedsAccessService.class);
	static final int maxSize = 200;
	static final String indexName = "feedsffan";
	static final String type="1";
	static final int ALL_COUNT = 10000000;
	FeedsAccess access = new FeedsAccess();

	public FeedsAccessService(Properties prop) {
		access = new FeedsAccess();
		access.handler = new ElasticsearchHandler(prop);
	}

	public FeedsAccessService() {
		access = new FeedsAccess();
		if (Init.esProp == null) {
			Init.init();
		}
		access.handler = new ElasticsearchHandler(Init.esProp);
	}

	public void closeAccess() {
		if (access != null) {
			access.closeHander();
		}
	}

	public List<RecordBase> getAllRecordesSortEstime(SQLCallback callback, int count) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(count);
		RequestBase.Sort sort = new RequestBase.Sort();
		sort.sortFiled = "updateTime";
		sort.sortType = RequestBase.SortType.DESC;
		req.setSort(sort);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("categoryIds");
		sourceFields.add("article.title");
		sourceFields.add("article.text");
		req.setSourcefeilds(sourceFields);
		// Map<String, QueryStruct> queryStruct = new HashMap<String,
		// QueryStruct>();
		// QueryStruct qs = new QueryStruct();
		// qs.keyword = "20170904000000";
		// qs.relation = Relationship.timeRange;
		// queryStruct.put("esUpdateTime", qs);
		// req.setFreeQuery(queryStruct);
		SearchResult sResult = null;

		try {
			sResult = access.select(req, WriteToFileCallback.DataCleanFormateDocument.class, callback);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		if (sResult == null || sResult.getHitCount() == 0) {
			return null;
		}
		return sResult.getRecord();

	}

	public int getAllRecordes(SQLCallback callback, int count) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(count);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("isPremium");
		sourceFields.add("subType");
		sourceFields.add("entryId");

		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;

		try {
			sResult = access.select(req, DocumentRecord.class, callback);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		return sResult.getHitCount();

	}

	public DocumentRecord getRecordById(String id) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(1);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("isPremium");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("subType");
		sourceFields.add("consumeScore");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;
		Map<String, RequestBase.QueryStruct> queryStruct = new HashMap<String, RequestBase.QueryStruct>();
		RequestBase.QueryStruct qs = new RequestBase.QueryStruct();
		qs.keyword = id;
		qs.relation = RequestBase.Relationship.term;
		queryStruct.put("id", qs);
		req.setFreeQuery(queryStruct);
		try {
			sResult = access.select(req, DocumentRecord.class, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		if (sResult == null || sResult.getHitCount() == 0) {
			return null;
		}
		return (DocumentRecord) sResult.getRecord().get(0);
	}

	public static void main(String[] args) {

		FeedsAccessService service = new FeedsAccessService();
		List<RecordBase> list = service.getAllRecordesSortEstime(new WriteToFileCallback(), 50000);
		ElasticsearchHandler h = (ElasticsearchHandler) service.access.handler;
		h.closeEsClient();
		System.out.println("输出集合总数:" + list.size());

		// // InitListener
		// FeedsRequest req = new FeedsRequest();
		// req.setIndexname("feeds");
		// req.setSize(100);
		// req.setStart(0);
		// FeedsAccess access = new FeedsAccess();
		// access.handler = new ElasticsearchHandler(Init.esProp);
		// // req.setSort(sort);
		// // Result<List<ModelResult>> result = Result.okResult();
		//
		// SearchResult res = access.select(req, DocumentRecord.class);
		// System.out.println(JSONObject.toJSONString(res));
	}

	/**
	 *
	 * @param time
	 *            格式为 yyyyMMddHHmmss
	 * @return
	 */
	public List<RecordBase> getRecordByTime(SQLCallback callback, String time) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setType(type);
		req.setSize(ALL_COUNT);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("isPremium");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("subType");
		sourceFields.add("consumeScore");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;
		Map<String, QueryStruct> queryStruct = new HashMap<String, QueryStruct>();
		QueryStruct qs = new QueryStruct();
		qs.keyword = time;
		qs.relation = Relationship.timeRange;
		queryStruct.put("esUpdateTime", qs);
		req.setFreeQuery(queryStruct);
		try {
			sResult = access.select(req, DocumentRecord.class, callback);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		if (sResult == null || sResult.getHitCount() == 0) {
			return null;
		}
		return sResult.getRecord();
	}

	/**
	 *
	 * @param doc
	 * @return
	 */
	public List<RecordBase> getSimRecords(DocumentRecord doc) throws Exception {
//		if(true){
//			return getRandomRecords();
//		}
		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(maxSize);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("isPremium");
		sourceFields.add("subType");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;
		try {
			if (doc.getNlps() != null && doc.getNlps().get("COMMONS") != null) {
				Map<String, QueryStruct> queryStruct = new HashMap<String, QueryStruct>();
				if (doc.getNlps().get("COMMONS").getTopics() != null
						&& doc.getNlps().get("COMMONS").getTopics().get("TOPIC64") != null) {
					Set<String> set = doc.getNlps().get("COMMONS").getTopics().get("TOPIC64").keySet();
					String topics = "";
					if (set != null) {
						for (String str : set) {
							if (doc.getNlps().get("COMMONS").getTopics().get("TOPIC64").get(str) < 0.1) {
								break;
							}
							topics += str + " ";
						}
						QueryStruct qs = new QueryStruct();
						qs.keyword = topics.trim();
						qs.relation = Relationship.term;
						queryStruct.put("topic64.key", qs);
					}
				}
				if (doc.getNlps().get("COMMONS").getCategories() != null) {

					Set<String> set = doc.getNlps().get("COMMONS").getCategories().keySet();
					String cates = "";
					if (set != null) {
						for (String str : set) {
							cates += str + " ";
						}
					}
					QueryStruct keyQs = new QueryStruct();
					keyQs.keyword = cates.trim();
					keyQs.relation = Relationship.term;
					queryStruct.put("category.key", keyQs);
				}

				if (doc.getNlps().get("COMMONS").getKeywords() != null) {

					Set<String> set = doc.getNlps().get("COMMONS").getKeywords().keySet();
					String cates = "";
					if (set != null && set.size() > 0) {
						for (String str : set) {
							cates += str + " ";
						}
					}
					if (cates.length() > 0) {
						QueryStruct keyQs = new QueryStruct();
						keyQs.keyword = cates.trim();
						keyQs.relation = Relationship.term;
						queryStruct.put("keyword.key", keyQs);
					}

				}

				req.setFreeQuery(queryStruct);

			}

			sResult = access.select(req, DocumentRecord.class, null);
			if (sResult == null || sResult.getHitCount() == 0) {
				return getRandomRecords();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}

		return sResult.getRecord();
	}
	

	/**
	 * 
	 * @param
	 * @return
	 */
	private List<RecordBase> getRandomRecords() throws Exception {
		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(maxSize);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("isPremium");
		sourceFields.add("subType");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);

		SearchResult sResult = null;
		try {
			sResult = access.select(req, DocumentRecord.class, null);
			if (sResult == null || sResult.getHitCount() == 0) {
				return null;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		return sResult.getRecord();
	}

	public void getAllNormData(SQLCallback normback) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname("ndcg-doc");
		req.setSize(ALL_COUNT);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("id");
		sourceFields.add("topic64");
		sourceFields.add("createTime");
		sourceFields.add("updateTime");
		sourceFields.add("isPremium");
		sourceFields.add("topic256");
		sourceFields.add("keywords");
		sourceFields.add("category");
		sourceFields.add("premiumScore");
		sourceFields.add("subType");
		sourceFields.add("consumeScore");
		sourceFields.add("entryId");
		req.setSourcefeilds(sourceFields);

		try {
			 access.select(req, DocumentRecord.class, normback);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}

	}
}
