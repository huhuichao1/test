package com.wanda.feeds.dataaccess.access.query;


import com.wanda.feeds.common.entity.base.RequestBase;

import java.util.List;
import java.util.Map;


public class FeedsRequest extends RequestBase {

	private List<String> hasFields;

	public List<String> getHasFields() {
		return hasFields;
	}

	public void setHasFields(List<String> hasFields) {
		this.hasFields = hasFields;
	}

	private Map<String, String> disMaxFields;

	private List<String> sourcefeilds;

	public List<String> getSourcefeilds() {
		return sourcefeilds;
	}

	public void setSourcefeilds(List<String> sourcefeilds) {
		this.sourcefeilds = sourcefeilds;
	}

	public Map<String, String> getDisMaxFields() {
		return disMaxFields;
	}

	public void setDisMaxFields(Map<String, String> disMaxFields) {
		this.disMaxFields = disMaxFields;
	}
}
