package com.wanda.feeds.dataaccess.access;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.entity.base.RequestBase;
import com.wanda.feeds.common.entity.base.RequestBase.QueryStruct;
import com.wanda.feeds.common.entity.base.RequestBase.Relationship;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.common.utils.date.TimeFormat;
import com.wanda.feeds.dataaccess.access.base.DATA_ACCESS_TYPE;
import com.wanda.feeds.dataaccess.access.base.DataAccessBase;
import com.wanda.feeds.dataaccess.access.base.SearchResult;
import com.wanda.feeds.dataaccess.access.es.ElasticsearchHandler;
import com.wanda.feeds.dataaccess.access.query.FeedsRequest;
import com.wanda.feeds.dataaccess.listener.Init;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class FeedsAccess extends DataAccessBase {

	public FeedsAccess() {
		super(DATA_ACCESS_TYPE.FEEDS);
		// TODO Auto-generated constructor stub
	}

	public void closeHander() {
		((ElasticsearchHandler) this.handler).closeEsClient();

	}

	public SearchResult select(RequestBase base, Class<? extends RecordBase> T, SQLCallback callback) {
		// TODO Auto-generated method stub
		FeedsRequest req = (FeedsRequest) base;
		// OrgdataRequest request = (OrgdataRequest)base;
		// TODO Auto-generated method stub
		SearchResult result = null;
		try {
			result = ((ElasticsearchHandler) this.handler).searchByRustfulScroll(buildQuery(req), req.getIndexname(),
					req.getType(), req.getStart(), req.getSize(), buildSort(req), T, callback,
					getSourceFileds(req.getSourcefeilds()));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	private QueryBuilder buildQuery(FeedsRequest query) {
		// TODO Auto-generated method stub
		QueryBuilder q = QueryBuilders.matchAllQuery();

		if (query == null) {
			return q;
		}
		List<String> fields = query.getHasFields();
		BoolQueryBuilder quickQuery = QueryBuilders.boolQuery();

		if (fields != null && fields.size() > 0) {
			for (String s : fields) {
				quickQuery.must(QueryBuilders.existsQuery(s));
			}
		}

		// quickQuery
		if (query.getFreeQuery() != null) {
			q = QueryBuilders.boolQuery();
			Map<String, QueryStruct> map = query.getFreeQuery();
			Iterator<Entry<String, QueryStruct>> it = map.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry entry = (Map.Entry) it.next();
				String key = entry.getKey().toString();
				QueryStruct value = (QueryStruct) entry.getValue();
				if (value.relation == Relationship.timeRange) {
					String timestmp = String.valueOf(Long.valueOf(value.keyword) - 1);
					((BoolQueryBuilder) q).must(QueryBuilders.rangeQuery(key).gte(timestmp)
							.format(TimeFormat.DateType.DATE_14.getFormat()));
				} else if (value.relation != Relationship.not)
					((BoolQueryBuilder) q).should(QueryBuilders.multiMatchQuery(value.keyword, key));

				else {
					((BoolQueryBuilder) q).mustNot(QueryBuilders.termQuery(value.keyword, key));
				}
			}
		}

		q = QueryBuilders.boolQuery().must(q).must(quickQuery);
		// QueryBuilders.disMaxQuery().add(QueryBuilders.matchQuery("topic64"))
		// QueryStringQueryBuilders
		// if(query.getSourcefeilds()!=null &&
		// query.getSourcefeilds().length>0){
		//
		// FetchSourceContext sourceContext = new
		// FetchSourceContext(query.getSourcefeilds());
		// }
		return q;
	}

	private SortBuilder buildSort(FeedsRequest query) {

		SortBuilder sort = null;
		if (query.getSort() != null) {
			SortOrder order = null;
			switch (query.getSort().sortType) {
			case ASC:
				order = SortOrder.ASC;
				break;
			case DESC:
				order = SortOrder.DESC;
				break;
			default:
				order = SortOrder.ASC;
				break;
			}

			sort = SortBuilders.fieldSort(query.getSort().sortFiled).order(order);

		}
		return sort;
	}

	public static void main(String[] args) {
		// InitListener
		FeedsRequest req = new FeedsRequest();
		req.setIndexname("feeds");
		req.setSize(100);
		req.setStart(0);
		FeedsAccess access = new FeedsAccess();
		access.handler = new ElasticsearchHandler(Init.esProp);
		// req.setSort(sort);
		// Result<List<ModelResult>> result = Result.okResult();

		SearchResult res = access.select(req, DocumentRecord.class);
		System.out.println(JSONObject.toJSONString(res));
	}

	public SearchResult select(RequestBase base, Class<? extends RecordBase> T) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		FeedsRequest req = (FeedsRequest) base;
		// OrgdataRequest request = (OrgdataRequest)base;
		// TODO Auto-generated method stub
		SearchResult result = null;
		try {
			result = ((ElasticsearchHandler) this.handler).searchByRustfulScroll(buildQuery(req), req.getIndexname(),
					req.getType(), req.getStart(), req.getSize(), buildSort(req), T, null,
					this.getSourceFileds(req.getSourcefeilds()));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
