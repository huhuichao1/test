package com.wanda.feeds.dataaccess.service;


import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.entity.base.RequestBase.QueryStruct;
import com.wanda.feeds.common.entity.base.RequestBase.Relationship;
import com.wanda.feeds.dataaccess.access.FeedsAccess;
import com.wanda.feeds.dataaccess.access.base.SearchResult;
import com.wanda.feeds.dataaccess.access.es.ElasticsearchHandler;
import com.wanda.feeds.dataaccess.access.query.FeedsRequest;
import com.wanda.feeds.dataaccess.listener.Init;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.dataaccess.record.ProfileRecord;
import org.apache.log4j.Logger;

import java.util.*;

public class UserAccessService implements AccessService {

	private static Logger logger = Logger.getLogger(UserAccessService.class);
	private static final String indexName = "profile";
	private static final String superUserName = "superuser";
	static FeedsAccess access = new FeedsAccess();

	public UserAccessService(Properties prop) {
		access = new FeedsAccess();
		access.handler = new ElasticsearchHandler(prop);
	}

	public UserAccessService() {
		access = new FeedsAccess();
		if (Init.esProp == null) {
			Init.init();
		}
		access.handler = new ElasticsearchHandler(Init.esProp);
	}

	public static void closeAccess() {
		if (access != null) {
			access.closeHander();
		}
	}

	public ProfileRecord getRecordById(String id) {

		FeedsRequest req = new FeedsRequest();
		req.setIndexname(indexName);
		req.setSize(1);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("categoryPreference");
		sourceFields.add("keywordPreference");
		sourceFields.add("topic64Preference");
		sourceFields.add("userId");
		sourceFields.add("age");
		sourceFields.add("gender");
		sourceFields.add("targetCity");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;
		Map<String, QueryStruct> queryStruct = new HashMap<String, QueryStruct>();
		QueryStruct qs = new QueryStruct();
		qs.keyword = id;
		qs.relation = Relationship.term;
		queryStruct.put("id", qs);
		req.setFreeQuery(queryStruct);
		try {
			sResult = access.select(req, ProfileRecord.class, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		if (sResult == null || sResult.getHitCount() == 0) {
			return null;
		}
		return (ProfileRecord) sResult.getRecord().get(0);
	}

	
	public List<RecordBase> getSuperUserPrifile(){
		FeedsRequest req = new FeedsRequest();
		req.setIndexname(superUserName);
		req.setSize(10);
		List<String> sourceFields = new ArrayList<String>();
		sourceFields.add("categoryPreference");
		sourceFields.add("keywordPreference");
		sourceFields.add("topic64Preference");
		sourceFields.add("userId");
		sourceFields.add("age");
		sourceFields.add("gender");
		sourceFields.add("targetCity");
		req.setSourcefeilds(sourceFields);
		SearchResult sResult = null;
//		Map<String, QueryStruct> queryStruct = new HashMap<String, QueryStruct>();
//		QueryStruct qs = new QueryStruct();
//		qs.keyword = id;
//		qs.relation = Relationship.term;
//		queryStruct.put("id", qs);
//		req.setFreeQuery(queryStruct);
		try {
			sResult = access.select(req, ProfileRecord.class, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		if (sResult == null || sResult.getHitCount() == 0) {
			return null;
		}
		return sResult.getRecord();
	}
	public static void main(String[] args) {

		UserAccessService service = new UserAccessService();
		ProfileRecord list = service.getRecordById("101000000234");
		ElasticsearchHandler h = (ElasticsearchHandler) service.access.handler;
		h.closeEsClient();
		System.out.println("输出集合总数:" + list);

		// // InitListener
		// FeedsRequest req = new FeedsRequest();
		// req.setIndexname("feeds");
		// req.setSize(100);
		// req.setStart(0);
		// FeedsAccess access = new FeedsAccess();
		// access.handler = new ElasticsearchHandler(Init.esProp);
		// // req.setSort(sort);
		// // Result<List<ModelResult>> result = Result.okResult();
		//
		// SearchResult res = access.select(req, DocumentRecord.class);
		// System.out.println(JSONObject.toJSONString(res));
	}

	@Override
	public List<RecordBase> getSimRecords(DocumentRecord doc) throws Exception {
		return null;
	}
}
