package com.wanda.feeds.dataaccess.access.base;

public interface IAccessHandler {
	
}
