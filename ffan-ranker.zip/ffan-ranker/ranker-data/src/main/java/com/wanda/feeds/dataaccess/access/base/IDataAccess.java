package com.wanda.feeds.dataaccess.access.base;


import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.entity.base.RequestBase;
import com.wanda.feeds.common.utils.callback.SQLCallback;

public interface IDataAccess {
	public SearchResult select(RequestBase base, Class<? extends RecordBase> T);

	public SearchResult select(RequestBase base, Class<? extends RecordBase> T, SQLCallback callback);

}
