package com.wanda.feeds.dataaccess.record;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.doc.NLPFeature;
import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.common.entity.base.RecordBase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DocumentRecord extends RecordBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Long getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	public Long getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Long updateTime) {
		this.updateTime = updateTime;
	}

	public Map<String, NLPFeature> getNlps() {
		return nlp;
	}

	public void setNlps(Map<String, NLPFeature> nlps) {
		this.nlp = nlps;
	}

	private Long createTime;
	private Long updateTime;
	private boolean isPremium;

	private List<KeyValuePair> topic64;
	private List<KeyValuePair> topic256;
	private List<KeyValuePair> category;
	private List<KeyValuePair> keywords;
	private int articleLen;
	private int mediaType;
	private int imageCount;
	private double premiumScore;
	private double consumeScore;
	private Integer subType;
	private String entryId;

	@Override
	public RecordBase build(JSONObject hit) {
		DocumentRecord record = new DocumentRecord();
		record.isPremium = hit.getBoolean("isPremium") == null ? false : hit.getBoolean("isPremium");
		record.id = hit.getString("id");
		record.createTime = Long.parseLong( hit.get("createTime").toString());
		record.updateTime = Long.parseLong( hit.get("updateTime").toString());
		if (hit.getFloat("premiumScore") != null) {
			record.premiumScore = (double) hit.getFloat("premiumScore");
		}
		record.entryId = hit.getString("entryId");
		record.subType = (Integer) hit.get("subType");
		if (hit.getFloat("consumeScore") != null) {
			record.consumeScore = (double) hit.getFloat("consumeScore");
		}
		// private Integer subType;
		// private String entryId;
		record.nlp = new HashMap<String, NLPFeature>();
		// record.keywords = hit.get("");
		List<KeyValuePair> keywordList = new ArrayList<KeyValuePair>();
		List<KeyValuePair> topic64List = new ArrayList<KeyValuePair>();
		List<KeyValuePair> cateList = new ArrayList<KeyValuePair>();
		List<KeyValuePair> topic256List = new ArrayList<KeyValuePair>();
		NLPFeature nlpFeature = new NLPFeature();
		if (hit.get("topic64") != null) {
			JSONArray topic64 = hit.getJSONArray("topic64");
			int size = topic64.size();
			Map<String, Double> tp = new HashMap<String, Double>();
			for (int index = 0; index < size; index++) {
				KeyValuePair pair = (KeyValuePair) JSONObject.toJavaObject(topic64.getJSONObject(index),
						KeyValuePair.class);
				topic64List.add(pair);
				tp.put(pair.getKey(), pair.getValue());
			}
			Map<String, Map<String, Double>> tps = new HashMap<String, Map<String, Double>>();
			tps.put("TOPIC64", tp);
			nlpFeature.setTopics(tps);
			record.topic64 = topic64List;
		}
		if (hit.get("topic256") != null) {
			JSONArray topic256 = hit.getJSONArray("topic256");
			int size = topic256.size();
			Map<String, Double> tp = new HashMap<String, Double>();
			for (int index = 0; index < size; index++) {
				KeyValuePair pair = (KeyValuePair) JSONObject.toJavaObject(topic256.getJSONObject(index),
						KeyValuePair.class);
				topic256List.add(pair);
				tp.put(pair.getKey(), pair.getValue());
			}
			Map<String, Map<String, Double>> tps = new HashMap<String, Map<String, Double>>();
			tps.put("TOPIC256", tp);
			nlpFeature.setTopics(tps);
			record.topic256 = topic256List;
		}
		if (hit.get("keywords") != null) {
			JSONArray keywords = hit.getJSONArray("keywords");
			int size = keywords.size();
			Map<String, Double> tp = new HashMap<String, Double>();
			for (int index = 0; index < size; index++) {
				KeyValuePair pair = (KeyValuePair) JSONObject.toJavaObject(keywords.getJSONObject(index),
						KeyValuePair.class);
				keywordList.add(pair);
				tp.put(pair.getKey(), pair.getValue());
			}
			record.keywords = keywordList;
			nlpFeature.setKeywords(tp);
		}

		if (hit.get("category") != null) {
			JSONArray category = hit.getJSONArray("category");
			int size = category.size();
			Map<String, Double> tp = new HashMap<String, Double>();
			for (int index = 0; index < size; index++) {
				KeyValuePair pair = (KeyValuePair) JSONObject.toJavaObject(category.getJSONObject(index),
						KeyValuePair.class);
				cateList.add(pair);
				tp.put(pair.getKey(), pair.getValue());
			}
			nlpFeature.setCategories(tp);
			record.category = cateList;
		}

		record.nlp.put("COMMONS", nlpFeature);
		// if (hit.get("nlp") != null) {
		// Map<String, Object> maps = (Map<String, Object>)
		// JSONObject.toBean(hit.getJSONObject("nlp"), Map.class);
		// // 循环查找nlp
		// Iterator<Map.Entry<String, Object>> it = maps.entrySet().iterator();
		// while (it.hasNext()) {
		// Map.Entry<String, Object> entry = it.next();
		// JSONObject obj = JSONObject.fromObject(entry.getValue());
		// if (obj != null) {
		// JSONObject topicsObject = obj.getJSONObject("topics");
		// NLPFeature nlpFeature = new NLPFeature();
		// if (topicsObject != null) {
		// Map<String, Map<String, Double>> topics = (Map<String, Map<String,
		// Double>>) JSONObject
		// .toBean(topicsObject, Map.class);
		// nlpFeature.setTopics(topics);
		// }
		//
		// JSONObject categoryObject = obj.getJSONObject("categories");
		// // NLPFeature nlpFeature = new NLPFeature();
		// if (categoryObject != null) {
		// Map<String, Double> cates = (Map<String, Double>)
		// JSONObject.toBean(categoryObject, Map.class);
		// nlpFeature.setCategories(cates);
		// }
		// JSONObject keywords = obj.getJSONObject("keywords");
		// // NLPFeature nlpFeature = new NLPFeature();
		// if (keywords != null) {
		// Map<String, Double> words = (Map<String, Double>)
		// JSONObject.toBean(keywords, Map.class);
		// nlpFeature.setKeywords(words);
		// }
		// record.nlp.put(entry.getKey(), nlpFeature);
		// }
		//
		// }
		//
		// }
		return record;
	}

	public int getArticleLen() {
		return articleLen;
	}

	public void setArticleLen(int articleLen) {
		this.articleLen = articleLen;
	}

	public boolean isPremium() {
		return isPremium;
	}

	public void setPremium(boolean premium) {
		isPremium = premium;
	}

	private Map<String, NLPFeature> nlp;

	public List<KeyValuePair> getTopic64() {
		return topic64;
	}

	public void setTopic64(List<KeyValuePair> topic64) {
		this.topic64 = topic64;
	}

	public List<KeyValuePair> getCategory() {
		return category;
	}

	public void setCategory(List<KeyValuePair> category) {
		this.category = category;
	}

	public List<KeyValuePair> getKeywords() {
		return keywords;
	}

	public void setKeywords(List<KeyValuePair> keywords) {
		this.keywords = keywords;
	}

	public int getImageCount() {
		return imageCount;
	}

	public void setImageCount(int imageCount) {
		this.imageCount = imageCount;
	}

	public int getMediaType() {
		return mediaType;
	}

	public void setMediaType(int mediaType) {
		this.mediaType = mediaType;
	}

	public double getPremiumScore() {
		return premiumScore;
	}

	public void setPremiumScore(double premiumScore) {
		this.premiumScore = premiumScore;
	}

	public static void main(String[] args) {
		// String str =
		// "{\"id\":\"24420221288710144\",\"type\":2,\"subType\":1,\"status\":1,\"name\":\"栾川旅游大动作不断，西峡路在何方？\",\"categories\":[\"旅游\"],\"categoryIds\":[\"102\"],\"tags\":[{\"name\":\"自驾游\",\"type\":0,\"count\":0},{\"name\":\"老君山\",\"type\":0,\"count\":0},{\"name\":\"鸡冠洞\",\"type\":0,\"count\":0},{\"name\":\"伏牛山\",\"type\":0,\"count\":0}],\"domain\":\"toutiao.com\",\"thumbnails\":[{\"url\":\"http://p3.pstatp.com/list/31f40002f09d2985387b\",\"sizeType\":\"SMALL\"},{\"url\":\"http://p9.pstatp.com/list/31f0000164e1aea5b3b3\",\"sizeType\":\"SMALL\"},{\"url\":\"http://p1.pstatp.com/list/31f20002711aee218ef2\",\"sizeType\":\"SMALL\"}],\"defaultThumbnail\":{\"url\":\"http://p3.pstatp.com/list/190x124/31f40002f09d2985387b\",\"sizeType\":\"SMALL\"},\"internal\":{\"schemaVersion\":\"0.01\"},\"templateId\":\"19430640785031177\",\"createTime\":1502104436688,\"updateTime\":1502104440877,\"article\":{\"title\":\"栾川旅游大动作不断，西峡路在何方？\",\"summary\":\"西峡拥有中国西峡恐龙遗迹园、西峡老界岭2个国家5A级景区，龙潭沟、鹳河漂流风景区、西峡老君洞3个国家4A级景区以及国家水利风景区石门湖、国家森林公园寺山、国家级工业旅游示范点宛西制药工业园等众多著名景区。“好山好水西峡”
		// “水墨龙乡，生态西峡”成为西峡的宣传名片。\",\"content\":\"<div>\\n
		// <p>西<span>峡拥有中国西峡恐龙遗迹园、西峡老界岭2个国家5A级景区，龙潭沟、鹳河漂流风景区、西峡老君洞3个国家4A级景区以及国家水利风景区石门湖、国家森林公园寺山、国家级工业旅游示范点宛西制药工业园等众多著名景区。<\\/span><\\/p>\\n
		// <p>“好山好水西峡” “水墨龙乡，生态西峡”成为西峡的宣传名片。<\\/p>\\n
		// <p>同时也获得了不少殊荣：成功入围首批国家全域旅游示范区创建单位。<\\/p>\\n <p><img
		// src=\\\"http://p3.pstatp.com/large/31eb0003ae418003af52\\\"
		// img_width=\\\"591\\\" img_height=\\\"348\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>西峡的旅游推介会<\\/p>\\n
		// <p>西峡为旅游的发展也做了不少努力，南阳、西安、郑州、武汉等地的推介会为断展现。<\\/p>\\n <p><img
		// src=\\\"http://p9.pstatp.com/large/31f0000164e1aea5b3b3\\\"
		// img_width=\\\"638\\\" img_height=\\\"478\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p><strong>看看栾川<\\/strong><\\/p>\\n <p>大动作<\\/p>\\n <p>1<\\/p>\\n
		// <p>2016年4月，<strong>“奇境栾川”号高铁专列<\\/strong>为京西线高铁，每日往返于北京和西安。该列车共16节车厢，行程覆盖了京、冀、豫、陕四省市15个大中城市。<\\/p>\\n
		// <p>4月10日至5月10日(五一小长假除外，团队除外)，凡乘坐“奇境栾川”号高铁，包括G564、G656、G661、G665车次的旅客，凭实名制高铁票和身份证可免门票游览栾川县境内的老君山、鸡冠洞、重渡沟、龙峪湾、抱犊寨、养子沟和伏牛山滑雪乐园7个景区。此外，为了鼓励旅行社引客入栾，栾川县旅工委将拿出优惠政策，鼓励各地旅行社发行奇境栾川旅游专列。<\\/p>\\n
		// <p><img src=\\\"http://p3.pstatp.com/large/31f0000164e0065b616b\\\"
		// img_width=\\\"539\\\" img_height=\\\"296\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>大动作<\\/p>\\n <p>2<\\/p>\\n
		// <p>2017年4月增<strong>两列\\\"栾川\\\"冠名的高铁<\\/strong>。4月6日，中国铁路旅游扶贫公益项目启动仪式暨“奇境栾川”高铁列车首发仪式在郑州东站举行。两列全新涂装的“奇境栾川号”动车组正式亮相郑州东站，以清新自然的形象服务全国游客，标志着中国铁路总公司对口帮扶洛阳栾川旅游扶贫公益项目正式启动。<\\/p>\\n
		// <p><img src=\\\"http://p1.pstatp.com/large/31f40002f09ccf67f3b5\\\"
		// img_width=\\\"547\\\" img_height=\\\"361\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>冠名的两列“奇境栾川”号高铁列车分别为京郑西线高铁和郑沪线高铁，每日往返于北京西-洛阳龙门-西安北和上海虹桥-郑州东-洛阳龙门。<strong>行程覆盖了京、沪、冀、豫、陕、皖、苏七省市33个大中城市。<\\/strong><\\/p>\\n
		// <p><img src=\\\"http://p3.pstatp.com/large/31ed000165f2129e8cbe\\\"
		// img_width=\\\"496\\\" img_height=\\\"264\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>2017年4月6日至5月10日（五一小长假除外，团队除外），凡乘坐“奇境栾川”号高铁，包括G661、G660、G1812、G1809、G1822、G1823车次的旅客，凭实名制高铁票和身份证可享受以下政策：<\\/p>\\n
		// <p><img src=\\\"http://p1.pstatp.com/large/31f20002711aee218ef2\\\"
		// img_width=\\\"548\\\" img_height=\\\"361\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>1、参观洛阳国家牡丹园享受8折优惠，参观天堂明堂景区门票立减20元；<\\/p>\\n
		// <p>2、免门票游览栾川县境内的老君山、鸡冠洞、重渡沟、龙峪湾、抱犊寨、养子沟、伏牛山滑雪乐园、天河大峡谷、栾川东北虎园9家景区。<\\/p>\\n
		// <p><img src=\\\"http://p3.pstatp.com/large/31f40002f09d2985387b\\\"
		// img_width=\\\"548\\\" img_height=\\\"363\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>大动作<\\/p>\\n <p>3<\\/p>\\n <p><strong>高速免费<\\/strong><\\/p>\\n
		// <p>8月1日0点-8月20日24点
		// ，7座及以下（含7座）小型客车到洛栾高速栾川下站口、重渡沟下站口下站，都免收河南省内通行费用。<\\/p>\\n <p><img
		// src=\\\"http://p9.pstatp.com/large/31e90002cdd7c938fe86\\\"
		// img_width=\\\"640\\\" img_height=\\\"443\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>来自洛阳的周先生一行于00:01到达栾川收费站，成为首辆省内免费自驾车辆，栾川旅工委工作人员给第一辆幸运车主送上栾川旅游大礼包。<\\/p>\\n
		// <p><img src=\\\"http://p3.pstatp.com/large/31eb0003ae4294aa49cb\\\"
		// img_width=\\\"640\\\" img_height=\\\"476\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>自北京的黄女士一行于00:08到达栾川收费站，成为首辆省外免费自驾车辆，节省河南省内高速费高达315元，她们一行是看到栾川免高速费的优惠政策，特地前来的，之前她也来过栾川特别喜欢这里，今年是专程来避暑的，计划会多呆一段时间。<\\/p>\\n
		// <p>保障<\\/p>\\n <p><img
		// src=\\\"http://p1.pstatp.com/large/31f20002711daaed560a\\\"
		// img_width=\\\"640\\\" img_height=\\\"384\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>交通警察、旅游警察驻守高速路<\\/p>\\n <p><img
		// src=\\\"http://p9.pstatp.com/large/31f20002711cced72b60\\\"
		// img_width=\\\"640\\\" img_height=\\\"365\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>景区交通节点<\\/p>\\n <p>客流<\\/p>\\n <p><img
		// src=\\\"http://p1.pstatp.com/large/31ed000165f5598c1bf4\\\"
		// img_width=\\\"640\\\" img_height=\\\"329\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n <p><img
		// src=\\\"http://p1.pstatp.com/large/31f40002f09f2f615787\\\"
		// img_width=\\\"640\\\" img_height=\\\"358\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>服务<\\/p>\\n <p><img
		// src=\\\"http://p3.pstatp.com/large/31e90002cdd9b8c2f5f7\\\"
		// img_width=\\\"537\\\" img_height=\\\"367\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>质监局对全县加油站进行突击检查，<\\/p>\\n <p>确保来栾游客合法利益<\\/p>\\n <p><img
		// src=\\\"http://p9.pstatp.com/large/31e90002cdd8d056701c\\\"
		// img_width=\\\"640\\\" img_height=\\\"308\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n <p><img
		// src=\\\"http://p9.pstatp.com/large/31e90002cdda5b8e6e54\\\"
		// img_width=\\\"640\\\" img_height=\\\"343\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>栾川旅游住宿调度中心<\\/p>\\n <p><img
		// src=\\\"http://p3.pstatp.com/large/31eb0003ae457610a781\\\"
		// img_width=\\\"640\\\" img_height=\\\"364\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>栾川旅游服务工作人员及志愿者队伍<\\/p>\\n <p>成果<\\/p>\\n <p><img
		// src=\\\"http://p3.pstatp.com/large/31ed000165f62d1c569d\\\"
		// img_width=\\\"640\\\" img_height=\\\"417\\\"
		// alt=\\\"栾川旅游大动作不断，西峡路在何方？\\\" inline=\\\"0\\\"><\\/p>\\n
		// <p>高速免费活动第一天！全县接待工作平稳有序，虽天气小雨连绵，但丝毫不影响游客赴栾旅游的热情。截止到下午18点，共有来自全国各地自驾游车辆6618辆享受到本次高速免费政策！<\\/p>\\n
		// <p>说了这么多栾川的<\\/p>\\n <p>并不是为其宣传<\\/p>\\n <p>而是看看<\\/p>\\n
		// <p>山水为邻的栾川<\\/p>\\n <p>他们的做法<\\/p>\\n <p>大举全县之力重视<\\/p>\\n
		// <p>塑造旅游品牌<\\/p>\\n <p>思考新形式下<\\/p>\\n <p>西峡旅游<\\/p>\\n
		// <p>怎么办？<\\/p>\\n <p><strong>欢迎广大西峡网友<\\/strong><\\/p>\\n
		// <p><strong>献计献策<\\/strong><\\/p>\\n
		// <p><strong>讨论<\\/strong><\\/p>\\n<\\/div>\",\"media\":\"西峡龙乡人\",\"publishTime\":1502022120000,\"votes\":\"0\",\"comments\":\"3\",\"stars\":\"0\",\"followers\":\"0\"},\"nlp\":\"{\\\"COMMON\\\":{\\\"topics\\\":{\\\"TOPIC_64\\\":{\\\"topic_64_50\\\":0.03180803571428571,\\\"topic_64_0\\\":0.013950892857142858,\\\"topic_64_2\\\":0.013950892857142858,\\\"topic_64_1\\\":0.013950892857142858,\\\"topic_64_16\\\":0.03180803571428571,\\\"topic_64_4\\\":0.013950892857142858,\\\"topic_64_17\\\":0.04966517857142857,\\\"topic_64_3\\\":0.013950892857142858,\\\"topic_64_21\\\":0.03180803571428571,\\\"topic_64_45\\\":0.03180803571428571}},\\\"keywords\\\":{\\\"伏牛山\\\":1.0,\\\"鸡冠洞\\\":1.0,\\\"老君山\\\":1.0,\\\"自驾游\\\":1.0},\\\"categories\\\":{\\\"102\\\":1.0}}}\",\"esUpdateTime\":\"20170807191400\"}";
		// JSONObject json = JSONObject.fromObject(str);
		// Long createTime = (Long) json.get("createTime");
		// System.out.println(createTime);
		//
		// Long updateTime = (Long) json.get("updateTime");
		// System.out.println(updateTime);
		//
		// Map<String, NLPFeature> nlps = (Map<String, NLPFeature>) JSONObject
		// .toBean(JSONObject.fromObject(json.get("nlp")), Map.class);
		// System.out.println(JSONObject.fromObject(nlps).toString());

		// DocumentRecord record = (DocumentRecord)
		// JSONObject.toBean(,DocumentRecord.class);

	}

	public List<KeyValuePair> getTopic256() {
		return topic256;
	}

	public void setTopic256(List<KeyValuePair> topic256) {
		this.topic256 = topic256;
	}

	public String getEntryId() {
		return entryId;
	}

	public void setEntryId(String entryId) {
		this.entryId = entryId;
	}

	public Integer getSubType() {
		return subType;
	}

	public void setSubType(Integer subType) {
		this.subType = subType;
	}

	public double getConsumeScore() {
		return consumeScore;
	}

	public void setConsumeScore(double consumeScore) {
		this.consumeScore = consumeScore;
	}
}
