package com.wanda.feeds.dataaccess.access.base;

public enum DATA_ACCESS_TYPE {
	FEEDS,DEFAULT
	

}
