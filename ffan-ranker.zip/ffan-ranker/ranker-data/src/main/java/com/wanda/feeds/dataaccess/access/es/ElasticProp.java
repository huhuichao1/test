package com.wanda.feeds.dataaccess.access.es;


public class ElasticProp {
	private int port;
	private String host;
	private String cluster;
	private int httpPort;
	
	public String getHost() {
		return host;
	}
	
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	
	public void setHost(String host) {
		this.host = host;
	}

	public String getCluster() {
		return cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	public int getHttpPort() {
		return httpPort;
	}

	public void setHttpPort(int httpPort) {
		this.httpPort = httpPort;
	}

	
}
