package com.wanda.feeds.dataaccess.access.es;

import org.apache.http.HttpHost;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

import java.io.IOException;
import java.util.Properties;

public class ElasticsearchClient {

	public RestClient restClient;
	public Client client = new PreBuiltTransportClient(Settings.EMPTY);
	public boolean idel;
	public String url;

	public void init(Properties prop) {
		props.setPort(Integer.valueOf(prop.getProperty("elastic.port")));
		props.setHost(prop.getProperty("elastic.host").trim());
		props.setCluster(prop.getProperty("elastic.cluster").trim());
		props.setHttpPort(Integer.valueOf(prop.getProperty("elastic.httpport").trim()));
		System.out.println("elastic.cluster=" + prop.getProperty("elastic.cluster").trim());
		timeout = Integer.valueOf(prop.getProperty("elastic.timeout").trim());
		// settings = Settings.builder().put("cluster.name",
		// props.getCluster()).build();
		init();
	}

	// private static TransportClient client;
	ElasticProp props = new ElasticProp();
	int timeout;
	// Settings settings;

	public void setIdel(boolean b) {
		this.idel = b;
	}

	public boolean getIdel() {
		return this.idel;
	}

	public RestClient getClient() {
		return this.restClient;
	}

	public void closeClient() {
		try {
			this.restClient.close();
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void init() {
		restClient = RestClient.builder(new HttpHost(props.getHost(), props.getHttpPort(), "http"))
				.setMaxRetryTimeoutMillis(600000).build();

	}

	/**
	 * getTransportClient 获取client
	 * 
	 * @return
	 */
	public static ElasticsearchClient getInstance() {

		ElasticsearchClient tClient = new ElasticsearchClient();
		tClient.init();
		return tClient;
	}

}
