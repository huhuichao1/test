package com.wanda.feeds.dataaccess.service;

import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.dataaccess.record.DocumentRecord;

import java.util.List;

public interface AccessService {

	public List<RecordBase> getSimRecords(DocumentRecord doc) throws Exception;


}
