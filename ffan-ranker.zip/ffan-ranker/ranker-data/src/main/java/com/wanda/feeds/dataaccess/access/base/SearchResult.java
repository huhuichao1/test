package com.wanda.feeds.dataaccess.access.base;

import com.wanda.feeds.common.entity.base.RecordBase;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;



public class SearchResult implements IDataAccessResult {
	public class ResultStatus {
		public int errorCode;
		public String message;

	}

	public class ResultFacet {

	}

	private List<RecordBase> record;
	private int hitCount;
	private ResultStatus resultStatus = new ResultStatus();
	private ResultFacet facet;

	public SearchResult build(SearchResponse response, Class<? extends RecordBase> T) {
		// TODO Auto-generated method stub
		ResultStatus status = new ResultStatus();
		status.errorCode = 0;
		status.message = "Search OK";
		SearchResult result = new SearchResult();
		if (response == null) {
			status.message = "ES Error";
			status.errorCode = 1;
			result.setResultStatus(status);
			return result;
		}
		SearchHits hits = response.getHits();

		// result.hits.getTotalHits();
		SearchHit[] searchHists = hits.getHits();
		List<RecordBase> recordList = new ArrayList<RecordBase>();
		result.setHitCount((int) hits.getTotalHits());

		try {
			if (searchHists.length > 0) {
				for (SearchHit hit : searchHists) {
					RecordBase record = null;
					// System.out.println(hit.getSourceAsString());

					Method method = T.getMethod("build", SearchHit.class);
					Object o = T.newInstance();

					record = (RecordBase) method.invoke(o, hit);

					recordList.add(record);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// Logger.INFO
		}
		result.setRecord(recordList);
		result.setResultStatus(status);
		return result;
	}

	public List<RecordBase> getRecord() {
		return record;
	}

	public void setRecord(List<RecordBase> record) {
		this.record = record;
	}

	public int getHitCount() {
		return hitCount;
	}

	public void setHitCount(int hitCount) {
		this.hitCount = hitCount;
	}

	public ResultStatus getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(ResultStatus resultStatus) {
		this.resultStatus = resultStatus;
	}

	public ResultFacet getFacet() {
		return facet;
	}

	public void setFacet(ResultFacet facet) {
		this.facet = facet;
	}

}
