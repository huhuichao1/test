package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/9/26.
 */
public class BoostScore {

  public   Double boost;
  public  Double boostScore;
}
