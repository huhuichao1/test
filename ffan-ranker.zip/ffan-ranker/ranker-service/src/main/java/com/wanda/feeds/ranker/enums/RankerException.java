package com.wanda.feeds.ranker.enums;


/**
 * Created by hhc on 2017/6/15.
 */
public class RankerException extends Exception {
    private static final long serialVersionUID = -5984598672603910431L;
    private int               errCode;

    public RankerException(int errCode, String msg) {
        super(msg);
        this.errCode = errCode;
    }

    public RankerException(ExceptionEnum restReturnEnum) {
        super(restReturnEnum.getDesc());
        this.errCode = restReturnEnum.getCode();
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }
}
