package com.wanda.feeds.ranker.access;

import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.dataaccess.service.FeedsAccessService;
import com.wanda.feeds.ranker.rankers.builder.NLPFeatureBuilder;

import java.util.List;

public class AssociationAction {

	NLPFeatureBuilder builder;

	SQLCallback callback;
	SQLCallback normback;
	FeedsAccessService service;

	public AssociationAction() {
		builder = new NLPFeatureBuilder();
		callback = new EsCallback(builder);
		normback=new NormDataCallback(builder);
		service = new FeedsAccessService(InitListener.esProp);
	}


	public List<RecordBase> accessRecordByTime(String date) {
		List<RecordBase> records = service.getRecordByTime(callback, date);
		return records;
	}

	public void accessNormDataAccess(){
		service.getAllNormData(normback);
	}

}
