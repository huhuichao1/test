package com.wanda.feeds.ranker.register;

import com.wanda.feeds.ranker.access.AssociationAction;
import com.wanda.feeds.ranker.access.TimeTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by huhuichao on 2017/8/31.
 */
@Component
public class RMIServiceApplication implements InitializingBean {


    private final static Logger LOGGER = LoggerFactory.getLogger(RMIServiceApplication.class);

    @Value("${ranker.name}")
    private String rankers;
    @Value("${ranker.server.port}")
    private int port;
    @Value("${ranker.server.socket.port}")
    private int socketprot;

    private TimeTask timer = new TimeTask();
    private AssociationAction action = new AssociationAction();


    @Override
    public void afterPropertiesSet() throws Exception {
        timer.time(action);
        String[] rankerNames = rankers.split(",");
        for (int i = 0; i < rankerNames.length; i++) {
            LOGGER.info("启动rankerName：" + rankerNames[i] + "; socketprot：" + (socketprot + i));
            RMIService.createService(port, rankerNames[i], socketprot + i);
        }
//        action.accessNormDataAccess();
//        LOGGER.info("init metric doc success...metric docs总量:" + NormDataProcesser.featureMap.size());
    }


    public void setRankers(String rankers) {
        this.rankers = rankers;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setSocketprot(int socketprot) {
        this.socketprot = socketprot;
    }

    public String getRankers() {
        return rankers;
    }

    public int getPort() {
        return port;
    }

    public int getSocketprot() {
        return socketprot;
    }
}
