package com.wanda.feeds.ranker.rankers.scorer;


import com.wanda.feeds.common.entity.base.FeatureType;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.ranker.rankers.explain.NLPRankerV1Explain;
import com.wanda.feeds.ranker.rankers.explain.score.*;
import com.wanda.feeds.ranker.rankers.features.NLPRankFeature;
import org.jblas.DoubleMatrix;

import java.util.Arrays;
import java.util.Map;

/**
 * Created by huhuichao on 2017/8/15.
 */
public class NLPFeatureScorerV1 implements IScorer {

	public static final double boost_isPremium = 1.05;

	public static final double boost_time_score = 0.05;
	public static final double boost_keyword_feature_score = 0.25;
	public static final double boost_category_feature_score = 0.20;
	public static final double boost_topic64_feature_score = 0.25;
	public static final double boost_premium_score = 0.15;
	public static final double boost_hot_score_score = 0.05;
	public static final double boost_consume_score=0.05;

	@Override
	public Score calcScore(RankFeature userFeature, RankFeature docFeature,Boolean explain) {

		Score ret = new Score();
		double score = 0d;
		double time_score = 0d;
		double keyword_feature_score = 0d;
		double category_feature_score = 0d;
		double topic64_feature_score = 0d;
		double hot_score = 0d;
		double premium_score = 0d;
		double consume_score=0d;
		NLPRankFeature nlpRankFeature = (NLPRankFeature) docFeature;
		if (nlpRankFeature.updateTime != null) {
			time_score = Math.pow(0.85,
					Math.log1p(Math.max((System.currentTimeMillis() - nlpRankFeature.updateTime) / 86400000d, 0)));
		}
		if (nlpRankFeature.hotScore > 0 && nlpRankFeature.hotScore <= 1) {
			hot_score = nlpRankFeature.hotScore;
		}

		if(nlpRankFeature.consumeScore>0&&nlpRankFeature.consumeScore<=1){
			consume_score=nlpRankFeature.consumeScore;
		}
		Map<FeatureType, double[]> userFeatureMap = userFeature.featureMap;
		Map<FeatureType, double[]> docFeatureMap = docFeature.featureMap;
		if (userFeatureMap.size() != 0 && docFeatureMap.size() != 0) {
			if (userFeatureMap.get(FeatureType.KEYWORDS) != null && docFeatureMap.get(FeatureType.KEYWORDS) != null) {
				double[] userKeywordFeature = userFeatureMap.get(FeatureType.KEYWORDS);
				double[] docKeywordFeature = docFeatureMap.get(FeatureType.KEYWORDS);
				keyword_feature_score = cosineSimilarity(userKeywordFeature, docKeywordFeature);
			}

			if (userFeatureMap.get(FeatureType.CATEGORY) != null && docFeatureMap.get(FeatureType.CATEGORY) != null) {
				double[] userCategoryFeature = userFeatureMap.get(FeatureType.CATEGORY);
				double[] docCategoryFeature = docFeatureMap.get(FeatureType.CATEGORY);
				category_feature_score = cosineSimilarity(userCategoryFeature, docCategoryFeature);
			}

			if (userFeatureMap.get(FeatureType.TOPIC64) != null && docFeatureMap.get(FeatureType.TOPIC64) != null) {
				double[] userTopic64Feature = userFeatureMap.get(FeatureType.TOPIC64);
				double[] docTopic64Feature = docFeatureMap.get(FeatureType.TOPIC64);
				topic64_feature_score = cosineSimilarity(userTopic64Feature, docTopic64Feature);
			}
		}
		premium_score = nlpRankFeature.premiumScore;
		score = time_score * boost_time_score + keyword_feature_score * boost_keyword_feature_score
				+ category_feature_score * boost_category_feature_score
				+ topic64_feature_score * boost_topic64_feature_score + hot_score * boost_hot_score_score
				+ premium_score * boost_premium_score+ consume_score*boost_consume_score;
		if (nlpRankFeature.isPremium) {
			score = score * boost_isPremium;
		}
		ret.setScore(score);
		if(explain){
			ret.setExplain(toExplain(userFeature, nlpRankFeature, score, time_score, keyword_feature_score,
					category_feature_score, topic64_feature_score));
		}
		return ret;
	}

	private String toExplain(RankFeature userFeature, NLPRankFeature nlpRankFeature, double score, double time_score,
							 double keyword_feature_score, double category_feature_score, double topic64_feature_score){
		NLPRankerV1Explain explain=new NLPRankerV1Explain();

		KeywordScore keywordScore=new KeywordScore();
		KeywordScore.KeywordFeature keywordFeature=new KeywordScore.KeywordFeature();
		keywordFeature.user_keyword_feature=Arrays.toString(userFeature.featureMap.get(FeatureType.KEYWORDS));
		keywordFeature.doc_keyword_feature=Arrays.toString(nlpRankFeature.featureMap.get(FeatureType.KEYWORDS));
		keywordScore.keywordFeature=keywordFeature;
		keywordScore.keyword_feature_score= keyword_feature_score;
		keywordScore.boost=boost_keyword_feature_score;
		keywordScore.boostScore=boost_keyword_feature_score*keyword_feature_score;
		explain.keywordScore=keywordScore;

		CategoryScore categoryScore=new CategoryScore();
		CategoryScore.CategoryFeature categoryFeature=new CategoryScore.CategoryFeature();
		categoryFeature.user_category_feature=Arrays.toString(userFeature.featureMap.get(FeatureType.CATEGORY));
		categoryFeature.doc_category_feature=Arrays.toString(nlpRankFeature.featureMap.get(FeatureType.CATEGORY));
		categoryScore.categoryFeature=categoryFeature;
		categoryScore.category_feature_score=category_feature_score;
		categoryScore.boost=boost_category_feature_score;
		categoryScore.boostScore=boost_category_feature_score*category_feature_score;
		explain.categoryScore=categoryScore;

		Topic64Score topic64Score=new Topic64Score();
		Topic64Score.Topic64Feature topic64Feature=new Topic64Score.Topic64Feature();
		topic64Feature.user_topic64_feature=Arrays.toString(userFeature.featureMap.get(FeatureType.TOPIC64));
		topic64Feature.doc_topic64_feature=Arrays.toString(nlpRankFeature.featureMap.get(FeatureType.TOPIC64));
		topic64Score.topic64Feature=topic64Feature;
		topic64Score.topic64_feature_score=topic64_feature_score;
		topic64Score.boost=boost_topic64_feature_score;
		topic64Score.boostScore=boost_topic64_feature_score*topic64_feature_score;
		explain.topic64Score=topic64Score;

		TimeScore timeScore=new TimeScore();
		timeScore.time=nlpRankFeature.updateTime.toString();
		timeScore.time_score=time_score;
		timeScore.boost=boost_time_score;
		timeScore.boostScore=boost_time_score*time_score;
		explain.timeScore=timeScore;

		HotScore hotScore=new HotScore();
		hotScore.hot_score=nlpRankFeature.hotScore;
		hotScore.boost=boost_hot_score_score;
		hotScore.boostScore=boost_hot_score_score*nlpRankFeature.hotScore;
		explain.hotScore=hotScore;

		PremiumScore premiumScore=new PremiumScore();
		premiumScore.promium_score=nlpRankFeature.premiumScore;
		premiumScore.boost=boost_premium_score;
		premiumScore.boostScore=boost_premium_score*nlpRankFeature.premiumScore;
		explain.premiumScore=premiumScore;

		ConsumeScore consumeScore=new ConsumeScore();
		consumeScore.consume_score=nlpRankFeature.consumeScore;
		consumeScore.boost=boost_consume_score;
		consumeScore.boostScore=boost_consume_score*nlpRankFeature.consumeScore;
		explain.consumeScore=consumeScore;

		if (nlpRankFeature.isPremium) {
			explain.isPremium=true;
			explain.totalScore="total score = boost_isPremium("+boost_isPremium+") * score "+score;
		}else {
			explain.isPremium=false;
			explain.totalScore=String.valueOf(score);
		}
		return explain.toString();
	}

	/**
	 * 计算余弦相似度 长度必须一样
	 *
	 * @param v1
	 * @param v2
	 * @return
	 */
	public Double cosineSimilarity(double[] v1, double[] v2) {
		DoubleMatrix factorVector1 = new DoubleMatrix(v1);
		DoubleMatrix factorVector2 = new DoubleMatrix(v2);

		double norm1 = factorVector1.norm2(); // 在线性代数里面
												// norm函数是一种可以在空间向量里面对向量赋予长度和大小的函数
		double norm2 = factorVector2.norm2();
		if (norm1 < 0.000001 || norm2 < 0.000001) {
			return 0.0;
		}
		Double sim = factorVector1.dot(factorVector2) / (norm1 * norm2);
		return sim;// cosineSimilarity(factorVector,
		// itemVector);
	}

	public String explain(RankFeature userFeature, NLPRankFeature nlpRankFeature, double score, double time_score,
			double keyword_feature_score, double category_feature_score, double topic64_feature_score) {
		StringBuilder explain = new StringBuilder();
		explain.append("\n user_keyword_feature=" + Arrays.toString(userFeature.featureMap.get(FeatureType.KEYWORDS))
				+ "; doc_keyword_feature=" + Arrays.toString(nlpRankFeature.featureMap.get(FeatureType.KEYWORDS))
				+ "; keyword_feature_score=" + keyword_feature_score + "* weight：(" + boost_keyword_feature_score
				+ ") =" + keyword_feature_score * boost_keyword_feature_score + ";	\n\t");
		explain.append("user_category_feature=" + Arrays.toString(userFeature.featureMap.get(FeatureType.CATEGORY))
				+ "; doc_category_feature=" + Arrays.toString(nlpRankFeature.featureMap.get(FeatureType.CATEGORY))
				+ "; category_feature_score=" + category_feature_score + "* weight：(" + boost_category_feature_score
				+ ") =" + category_feature_score * boost_category_feature_score + ";\n\t");
		explain.append("user_topic64_feature=" + Arrays.toString(userFeature.featureMap.get(FeatureType.TOPIC64))
				+ "; doc_topic64_feature=" + Arrays.toString(nlpRankFeature.featureMap.get(FeatureType.TOPIC64))
				+ "; topic64_feature_score=" + topic64_feature_score + "* weight：(" + boost_topic64_feature_score
				+ ") =" + topic64_feature_score * boost_topic64_feature_score + ";\n\t");
		explain.append("time=" + nlpRankFeature.updateTime + "; time_score=" + time_score + "* weight：("
				+ boost_time_score + ") =" + time_score * boost_time_score + ";\n\t");
		explain.append("hotScore=" + nlpRankFeature.hotScore + "; hot_score=" + nlpRankFeature.hotScore + "* weight：("
				+ boost_hot_score_score + ") =" + nlpRankFeature.hotScore * boost_hot_score_score + " ;	\n\t");

		explain.append("premium_score=" + nlpRankFeature.premiumScore + "; premium_score=" + nlpRankFeature.premiumScore
				+ "* weight：(" + boost_premium_score + ") =" + nlpRankFeature.premiumScore * boost_premium_score
				+ ";\n\t");
		explain.append("isPremium=" +nlpRankFeature.isPremium+ ";\n\t");
		if (nlpRankFeature.isPremium) {
			explain.append("total score * boost_isPremium(" + boost_isPremium + ")=" + score + ";\n\t");
		} else {
			explain.append("total score=" + score + ";\n\t");
		}
		return explain.toString();
	}

}
