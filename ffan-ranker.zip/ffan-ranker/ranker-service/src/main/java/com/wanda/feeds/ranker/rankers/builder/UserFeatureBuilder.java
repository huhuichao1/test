package com.wanda.feeds.ranker.rankers.builder;


import com.wanda.feeds.common.entity.FeedsRecord;
import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.common.entity.base.FeatureType;
import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.ranker.rankers.features.NLPRankFeature;

import java.util.List;

/**
 * Created by huhuichao on 2017/8/14.
 */
public class UserFeatureBuilder extends FeatureBuilderBase {

	@Override
	public RankFeature buildFeature(UserProfile userProfile, FeedsRecord doc) {
		if (userProfile == null) {
			return null;
		}
		RankFeature feature = new NLPRankFeature();

		// 组建topic Feature
		double[] topicFeature = getUserTopicFeature(userProfile.getTopic64Preference());
		if (topicFeature != null) {
			feature.featureMap.put(FeatureType.TOPIC64, topicFeature);
		}

		// 添加keyword Feature
		double[] keywordFeature = getUserMapFeature(userProfile.getKeywordPreference(), keyword_vector_size);
		if (null != keywordFeature) {
			feature.featureMap.put(FeatureType.KEYWORDS, keywordFeature);
		}

		// 添加category Feature
		double[] categoryFeature = getUserCategoryFeature(userProfile.getCategoryPreference());
		if (null != categoryFeature) {
			feature.featureMap.put(FeatureType.CATEGORY, categoryFeature);
		}
		double[] features = getFeatuersArrayVector(topicFeature, keywordFeature, categoryFeature);
		// for(topicFeature)

		feature.features = features;
		return feature;
	}

	/**
	 * 获取用户nlp属性的feature vector 在传入的map中，按照value排序，取前featureLength个值
	 * 获取user的向量，长度为featureLength；
	 * 
	 * @param userPreference，用户nlp
	 *            属性之一
	 * @param featureLength，长度featureLength；
	 * @return
	 */
	protected double[] getUserMapFeature(List<KeyValuePair> userPreference, int featureLength) {
		double[] feature = new double[featureLength];
		if (userPreference == null || (userPreference != null && userPreference.size() == 0)) {
			return feature;
		}
		int length = userPreference.size() > featureLength ? featureLength : userPreference.size();
		double totalScore = 0.0000001;
		for (int i = 0; i < length; i++) {
			totalScore += userPreference.get(i).getValue();
		}

		for (int i = 0; i < length; i++) {
			feature[i] = userPreference.get(i).getValue() / totalScore;
		}
		return feature;
	}

	/**
	 * 这是用户的category向量
	 *
	 * @param userPreference
	 *            ,用户nlp属性之一
	 * @return
	 */
	protected double[] getUserCategoryFeature(List<KeyValuePair> userPreference) {
		double[] feature = new double[categoryMap.size()];
		if (userPreference == null || (userPreference != null && userPreference.size() == 0)) {
			return feature;
		}
		double totalScore = 0.0000001;
		for (KeyValuePair pair : userPreference) {
			if (categoryMap.get(pair.getKey()) != null) {
				totalScore += pair.getValue();
			}
		}

		for (KeyValuePair pair : userPreference) {
			if (categoryMap.get(pair.getKey()) == null) {
				continue;
			}
			feature[categoryMap.get(pair.getKey())] = pair.getValue() / totalScore;
		}
		return feature;
	}

	/**
	 * 这是用户的topic向量
	 *
	 * @param userPreference
	 *            ,用户nlp属性之一
	 * @return
	 */
	protected double[] getUserTopicFeature(List<KeyValuePair> userPreference) {
		double[] feature = new double[topic64_vector_size];

		if (userPreference == null || (userPreference != null && userPreference.size() == 0)) {
			return feature;
		}

		double totalScore = 0.0000001;
		for (KeyValuePair pair : userPreference) {
			if (topic64Map.get(pair.getKey()) != null) {
				totalScore += pair.getValue();
			}
		}

		for (KeyValuePair pair : userPreference) {
			if (topic64Map.get(pair.getKey()) != null) {
				feature[topic64Map.get(pair.getKey())] = pair.getValue() / totalScore;
			}
		}
		// Set<Map.Entry<String, Double>> set = userPreference.entrySet();
		// for (Map.Entry<String, Double> entry : set) {
		// feature[topicMap.get(entry.getKey())] =entry.getValue();
		// }
		return feature;
	}

	/**
	 * 把3个数组合并成一个
	 * 
	 * @param topicFeature
	 * @param keywordFeature
	 * @param categoryFeature
	 * @return
	 */
	private static double[] getFeatuersArrayVector(double[] topicFeature, double[] keywordFeature,
			double[] categoryFeature) {
		double[] features = new double[keyword_vector_size + category_vector_size + topic64_vector_size];
		for (int i = 0; i < topicFeature.length; i++) {
			features[i] = topicFeature[i];
		}

		for (int i = 0; i < keywordFeature.length; i++) {
			features[topic64_vector_size + i] = keywordFeature[i];
		}

		for (int i = 0; i < categoryFeature.length; i++) {
			features[topic64_vector_size + keyword_vector_size + i] = categoryFeature[i];
		}

		return features;
	}
}
