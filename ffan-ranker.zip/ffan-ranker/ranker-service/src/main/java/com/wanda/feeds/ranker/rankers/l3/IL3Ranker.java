package com.wanda.feeds.ranker.rankers.l3;

import com.wanda.feeds.common.entity.RankRecord;
import com.wanda.feeds.ranker.rankers.struct.L2RankRecord;

import java.util.List;

public interface IL3Ranker{
	List<RankRecord> ranking(List<L2RankRecord> records) throws Exception;
}
