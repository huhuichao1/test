package com.wanda.feeds.ranker.rankers.struct;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.common.entity.base.RecordBase;


public class L2RankRecord extends RecordBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String explain;
	private Double score = 0d;
	private RankFeature docFeature;

	public L2RankRecord(RankFeature docFeature, String id,String entryId,double score, String explain) {
		this.docFeature = docFeature;
		this.score = score;
		this.explain = explain;
		this.entryId = entryId;
		this.id = id;
	}
	
	public L2RankRecord(RankFeature docFeature, String id,String entryId,double score) {
		this.docFeature = docFeature;
		this.score = score;
		this.entryId = entryId;
		this.id = id;
	}


	@Override
	public RecordBase build(JSONObject hit) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getExplain() {
		return explain;
	}

	public void setExplain(String explain) {
		this.explain = explain;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public RankFeature getDocFeature() {
		return docFeature;
	}

	public void setDocFeature(RankFeature docFeature) {
		this.docFeature = docFeature;
	}

}
