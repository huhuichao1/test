package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/9/26.
 */
public class TimeScore extends BoostScore{

   public String time;
   public Double time_score;
}
