package com.wanda.feeds.ranker.rankers.explain;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.ranker.rankers.explain.score.*;

/**
 * Created by huhuichao on 2017/9/26.
 */
public class NLPRankerV1Explain extends Explain {
    public KeywordScore keywordScore;
    public CategoryScore categoryScore;
    public Topic64Score topic64Score;
    public TimeScore timeScore;
    public HotScore hotScore;
    public PremiumScore premiumScore;
    public ConsumeScore consumeScore;

    public Boolean isPremium;


    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
