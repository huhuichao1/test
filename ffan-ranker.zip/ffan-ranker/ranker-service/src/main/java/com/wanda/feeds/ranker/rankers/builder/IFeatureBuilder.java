package com.wanda.feeds.ranker.rankers.builder;


import com.wanda.feeds.common.entity.FeedsRecord;
import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.access.DocWithFeature;

public interface IFeatureBuilder {

	/**
	 * 
	 * @param userProfile
	 * @param doc
	 * @return
	 */
	RankFeature buildFeature(UserProfile userProfile, FeedsRecord doc);

	/**
	 * 
	 * @param doc
	 * @return
	 */
	DocWithFeature buildFeature(DocumentRecord doc);

	/**
	 * 
	 * @param userProfile
	 * @param doc
	 * @return
	 */
	DocWithFeature addKeywordFeature(UserProfile userProfile, DocWithFeature doc);
}
