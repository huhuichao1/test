package com.wanda.feeds.ranker.rankers.builder;


import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.common.utils.io.FileOperater;
import com.wanda.feeds.common.utils.io.MyCallBack;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.access.DocWithFeature;
import org.jblas.DoubleMatrix;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by huhuichao on 2017/8/14.
 */
public abstract class FeatureBuilderBase implements IFeatureBuilder {
	protected static final int keyword_vector_size = 10;
	protected static int category_vector_size;

	protected static final int topic64_vector_size = 64;
	private static String[] categorys;

	// 分类
	static Map<String, Integer> categoryMap = new HashMap<>();
	// topic64
	static Map<String, Integer> topic64Map = new HashMap<String, Integer>();

	static {
		// topic 64
		for (int index = 0; index < topic64_vector_size; index++) {
			topic64Map.put(String.valueOf(index + 1), index);
		}

		InputStream inputStream = FeatureBuilderBase.class.getResourceAsStream("/category");
		final List<String> categoryList = new ArrayList<String>();
		MyCallBack callback = new MyCallBack() {

			public void operation(String string, Object object) {
				// TODO Auto-generated method stub
				if (string != null) {
					String[] strs = string.split(" ");
					if (strs == null || strs.length < 2) {
						return;
					}
					categoryList.add(strs[1]);
				}
			}

		};

		FileOperater.readline(inputStream, callback);
		category_vector_size = categoryList.size();
		categorys = categoryList.toArray(new String[category_vector_size]);

		// 分类
		for (int i = 0; i < category_vector_size; i++) {
			categoryMap.put(categorys[i], i);
		}
	}

	public DocWithFeature addKeywordFeature(UserProfile userProfile, DocWithFeature doc) {
		return null;
	}

	public DocWithFeature buildFeature(DocumentRecord doc) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {

	}

	/**
	 * 计算余弦相似度
	 * 长度必须一样
	 *
	 * @param v1
	 * @param v2
	 * @return
	 */
	public Double cosineSimilarity(double[] v1, double[] v2) {
		DoubleMatrix factorVector1 = new DoubleMatrix(v1);
		DoubleMatrix factorVector2 = new DoubleMatrix(v2);

		double norm1 = factorVector1.norm2();  //在线性代数里面 norm函数是一种可以在空间向量里面对向量赋予长度和大小的函数
		double norm2 = factorVector2.norm2();
		if (norm1 < 0.000001 || norm2 < 0.000001) {
			return 0.0;
		}
		Double sim = factorVector1.dot(factorVector2) / (norm1 * norm2);
		return sim;// cosineSimilarity(factorVector,
// itemVector);
	}
}
