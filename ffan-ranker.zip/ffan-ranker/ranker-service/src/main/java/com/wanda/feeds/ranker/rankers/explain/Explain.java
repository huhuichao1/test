package com.wanda.feeds.ranker.rankers.explain;

/**
 * Created by huhuichao on 2017/9/25.
 */
public class Explain {

    public String   totalScore;

}
