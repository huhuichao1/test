package com.wanda.feeds.ranker.rankers.builder;

import com.wanda.feeds.common.entity.FeedsRecord;
import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.rankers.features.NLPPlusFeature;

import java.util.List;

/**
 * Created by huhuichao on 2017/8/10.
 */

public class NLPPlusFeatureBuilder extends FeatureBuilderBase {

	public double[] NLPPlusFeature(UserProfile userProfile, DocumentRecord doc) {
		NLPPlusFeature feature = buildFeature(userProfile, doc);
		double[] features = feature.nlpPlusFeatureVector(getDocTopicFeature(doc.getTopic64()),
				getDocCategoryFeature(doc.getCategory()));
		return features;
	}

	public NLPPlusFeature buildFeature(UserProfile userProfile, DocumentRecord doc) {
		// DocWithFeature docWithFeature = new DocWithFeature();
		NLPPlusFeature feature = new NLPPlusFeature();

		// NLPRankFeature feature = new NLPRankFeature();
		feature.timeScore = Math.pow(0.85,
				Math.log1p(Math.max((System.currentTimeMillis() - doc.getUpdateTime()) / 86400000d, 0)));
		feature.isPremium = doc.isPremium() == true ? 1 : 0;
		// feature.hotScore=doc.get
		feature.topic64Score = getAccumulateFeatureScore(userProfile.getTopic64ClickCnt(), doc.getTopic64()); // 获取topic64积累得分
		feature.categoryScore = getAccumulateFeatureScore(userProfile.getCategoryClickCnt(), doc.getCategory());
		feature.keywordScore = getKeywordFeatureScore(userProfile.getKeywordClickCnt(), doc.getKeywords());

		feature.articleLen = doc.getArticleLen();
		feature.mediaType = doc.getMediaType();

		feature.categorySim = getFeatureSim(userProfile.getCategoryPreference(), doc.getCategory(), "category");
		feature.topic64Sim = getFeatureSim(userProfile.getTopic64Preference(), doc.getTopic64(), "topic64");
		feature.imageCount = doc.getImageCount();
		return feature;

	}

	private double getFeatureSim(List<KeyValuePair> userFeature, List<KeyValuePair> docFeature, String type) {
		double score = 0;
		if (userFeature == null || docFeature == null) {
			return score;
		}
		if (userFeature.size() == 0 || docFeature.size() == 0) {
			return score;
		}
		double[] user = "category".equals(type) ? getUserCategoryFeature(userFeature)
				: getUserTopicFeature(userFeature);
		double[] doc = "category".equals(type) ? getDocCategoryFeature(docFeature) : getDocTopicFeature(docFeature);
		score = cosineSimilarity(user, doc);
		return score;
	}

	/**
	 * 获取积累得分,衰减底数为0.9
	 * 
	 * @param userFeature
	 * @param docFeature
	 * @return
	 */
	private double getKeywordFeatureScore(List<KeyValuePair> userFeature, List<KeyValuePair> docFeature) {
		double score = 0;
		if (userFeature == null || docFeature == null) {
			return score;
		}
		if (userFeature.size() == 0 || docFeature.size() == 0) {
			return score;
		}
		for (KeyValuePair ukv : userFeature) {
			for (int i = 0, size = docFeature.size(); i < size; i++) {
				if (ukv.getKey().equals(docFeature.get(i).getKey())) {
					score += ukv.getValue() * Math.pow(0.9, i);
					break;
				}
			}

		}
		return score;
	}

	/**
	 * 
	 * @param userFeature
	 * @param docFeature
	 * @return
	 */
	private double getAccumulateFeatureScore(List<KeyValuePair> userFeature, List<KeyValuePair> docFeature) {
		double score = 0;
		if (userFeature == null || docFeature == null) {
			return score;
		}
		if (userFeature.size() == 0 || docFeature.size() == 0) {
			return score;
		}
		for (KeyValuePair ukv : userFeature) {
			for (int i = 0, size = docFeature.size(); i < size; i++) {
				if (ukv.getKey().equals(docFeature.get(i).getKey())) {
					score += ukv.getValue() * docFeature.get(i).getValue();
					break;
				}
			}

		}
		return score;
	}

	@Override
	public RankFeature buildFeature(UserProfile userProfile, FeedsRecord doc) {
		return null;
	}

	/**
	 * 这是doc的category向量
	 *
	 * @param docFeature
	 *            ,doc 的feature
	 * @return
	 */
	public static double[] getDocCategoryFeature(List<KeyValuePair> docFeature) {
		double[] feature = new double[categoryMap.size()];

		if (docFeature == null || (docFeature != null && docFeature.size() == 0)) {
			return feature;
		}
		for (KeyValuePair entry : docFeature) {
			if (categoryMap.get(entry.getKey()) == null) {
				continue;
			}
			feature[categoryMap.get(entry.getKey())] = entry.getValue();
		}
		return feature;
	}

	/**
	 * 这是doc的topic向量
	 *
	 * @param docFeature
	 *            ,doc 的feature
	 * @return
	 */
	protected static double[] getDocTopicFeature(List<KeyValuePair> docFeature) {
		double[] feature = new double[topic64_vector_size];

		if (docFeature == null || (docFeature != null && docFeature.size() == 0)) {
			return feature;
		}
		for (KeyValuePair entry : docFeature) {
			if (topic64Map.get(entry.getKey()) == null) {
				continue;
			}
			feature[topic64Map.get(entry.getKey())] = entry.getValue();
		}
		return feature;
	}

	/**
	 * 这是用户的category向量
	 *
	 * @param userPreference
	 *            ,用户nlp属性之一
	 * @return
	 */
	protected double[] getUserCategoryFeature(List<KeyValuePair> userPreference) {
		double[] feature = new double[categoryMap.size()];
		if (userPreference == null || (userPreference != null && userPreference.size() == 0)) {
			return feature;
		}
		for (KeyValuePair pair : userPreference) {
			if (categoryMap.get(pair.getKey()) == null) {
				continue;
			}
			feature[categoryMap.get(pair.getKey())] = pair.getValue();
		}
		return feature;
	}

	/**
	 * 这是用户的topic向量
	 *
	 * @param userPreference
	 *            ,用户nlp属性之一
	 * @return
	 */
	protected double[] getUserTopicFeature(List<KeyValuePair> userPreference) {
		double[] feature = new double[topic64_vector_size];
		if (userPreference == null || (userPreference != null && userPreference.size() == 0)) {
			return feature;
		}
		for (KeyValuePair pair : userPreference) {
			if (topic64Map.get(pair.getKey()) != null) {
				feature[topic64Map.get(pair.getKey())] = pair.getValue();
			}
		}
		// Set<Map.Entry<String, Double>> set = userPreference.entrySet();
		// for (Map.Entry<String, Double> entry : set) {
		// feature[topicMap.get(entry.getKey())] =entry.getValue();
		// }
		return feature;
	}
}
