package com.wanda.feeds.ranker.utils;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.NLPToolResult;
import com.wanda.feeds.common.entity.ParamJson;
import com.wanda.feeds.common.entity.base.KeyValuePair;

public class NetAccessUtil {

	public static Long timer;
	private static final String APPLICATION_JSON = "application/json";

	private static final String CONTENT_TYPE_TEXT_JSON = "application/json";

	public static class CrawlerResponse {
		public int status;
		public String response;
	}

	static {
		timer = System.currentTimeMillis();
		System.out.println("Crawler Start:" + timer);
	}

	@SuppressWarnings("finally")
	public static List<String> getLoginCookie(String url, List<NameValuePair> login) {
		List<String> cookiees = new ArrayList<String>();
		HttpClient httpclient = new DefaultHttpClient();
		try {

			// HttpPost httppost = new
			// HttpPost("http://mshow.intra.ffan.com/user/login_submit");
			HttpPost httppost = new HttpPost(url);
			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(-1).setConnectionRequestTimeout(-1)
					.setSocketTimeout(-1).build();
			httppost.setConfig(requestConfig);
			/*
			 * List<NameValuePair> params = new ArrayList<NameValuePair>();
			 * params.add(new BasicNameValuePair("username", "shiyongping"));
			 * params.add(new BasicNameValuePair("password", "love1123"));
			 */
			httppost.setEntity(new UrlEncodedFormEntity(login));

			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			// 在这里可以用Jsoup之类的工具对返回结果进行分析，以判断登录是否成功
			String postResult = EntityUtils.toString(entity, "UTF-8");

			// 我们这里只是简单的打印出当前Cookie值以判断登录是否成功。
			// CookieStore cookieStore = ((AbstractHttpClient)
			// httpclient).getCookieStore();

			List<Cookie> cookies = ((AbstractHttpClient) httpclient).getCookieStore().getCookies();
			for (Cookie cookie : cookies)
				cookiees.add(cookie.toString());
			// httppost.releaseConnection();

		} catch (Exception e) {

		} finally {
			return cookiees;
		}
	}

	@SuppressWarnings("finally")
	public static List<Cookie> getLoginCookies️(String url, List<NameValuePair> login) {
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url);

		try {
			httppost.setEntity(new UrlEncodedFormEntity(login));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			// 在这里可以用Jsoup之类的工具对返回结果进行分析，以判断登录是否成功
			String postResult = EntityUtils.toString(entity, "UTF-8");
			System.out.println("====login====");
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Cookie> cookies = ((AbstractHttpClient) httpclient).getCookieStore().getCookies();
		return cookies;

	}

	/**
	 * http://mshow.intra.ffan.com/user/login 获取httpClient
	 * 
	 */
	@SuppressWarnings("finally")
	public static HttpClient getLoginClient(String url, List<NameValuePair> login) {
		HttpClient httpclient = new DefaultHttpClient();
		try {

			// HttpPost httppost = new
			// HttpPost("http://mshow.intra.ffan.com/user/login_submit");
			HttpPost httppost = new HttpPost(url);
			/*
			 * List<NameValuePair> params = new ArrayList<NameValuePair>();
			 * params.add(new BasicNameValuePair("username", "shiyongping"));
			 * params.add(new BasicNameValuePair("password", "love1123"));
			 */
			httppost.setEntity(new UrlEncodedFormEntity(login));

			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			// 在这里可以用Jsoup之类的工具对返回结果进行分析，以判断登录是否成功
			String postResult = EntityUtils.toString(entity, "UTF-8");

			// 我们这里只是简单的打印出当前Cookie值以判断登录是否成功。
			CookieStore cookieStore = ((AbstractHttpClient) httpclient).getCookieStore();

			// List<Cookie> cookies = ((AbstractHttpClient)
			// httpclient).getCookieStore().getCookies();

			// httppost.releaseConnection();
			return httpclient;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			return httpclient;
		}
	}

	/**
	 * 通过Get方法获取Entity
	 * 
	 * @param httpclient
	 * @param url
	 * @param params
	 * @return
	 */
	public static CrawlerResponse getGetEntity(HttpClient httpclient, String url) {
		CrawlerResponse responses = new CrawlerResponse();
		try {
			HttpGet httpget = new HttpGet(url);
			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(-1).setConnectionRequestTimeout(-1)
					.setSocketTimeout(-1).build();
			httpget.setConfig(requestConfig);
			HttpResponse response = httpclient.execute(httpget);

			responses.status = response.getStatusLine().getStatusCode();
			if (responses.status == 200) {
				HttpEntity entity = response.getEntity();
				String postResult = EntityUtils.toString(entity, "UTF-8");
				responses.response = postResult;
			}
			// response.get
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responses;
	}

	/**
	 * 通过Post方法获取Entity
	 * 
	 * @param httpclient
	 * @param url
	 * @param params
	 * @return
	 */
	public static CrawlerResponse getPostEntity(HttpClient httpclient, String url, List<NameValuePair> params) {
		CrawlerResponse responses = new CrawlerResponse();
		try {
			HttpPost post = new HttpPost(url);
			post.addHeader(HTTP.CONTENT_TYPE, APPLICATION_JSON);
			post.addHeader("Accept-Charset", "utf-8");
			post.addHeader("User-Agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.160 Safari/537.22");

			post.setEntity(new UrlEncodedFormEntity(params));

			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(-1).setConnectionRequestTimeout(-1)
					.setSocketTimeout(-1).build();
			post.setConfig(requestConfig);
			HttpResponse response = httpclient.execute(post);

			responses.status = response.getStatusLine().getStatusCode();
			if (responses.status == 200) {
				HttpEntity entity = response.getEntity();
				String postResult = EntityUtils.toString(entity, "UTF-8");
				responses.response = postResult;
			}
			// response.get
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responses;
	}

	/**
	 * 通过Post方法获取Entity
	 * 
	 * @param httpclient
	 * @param url
	 * @param params
	 * @return
	 */
	public static CrawlerResponse getPostEntity(HttpClient httpclient, String url, String params) {
		CrawlerResponse responses = new CrawlerResponse();
		try {
			HttpPost post = new HttpPost(url);
			post.addHeader(HTTP.CONTENT_TYPE, APPLICATION_JSON);
			post.addHeader("Accept-Charset", "utf-8");
			params = params.replace("\n", "");
			StringEntity postingString = new StringEntity(params, "utf-8");
			// post.setEntity(new UrlEncodedFormEntity(params));

			/*
			 * RequestConfig requestConfig = RequestConfig.custom()
			 * .setConnectTimeout(-1).setConnectionRequestTimeout(-1)
			 * .setSocketTimeout(-1).build(); post.setConfig(requestConfig);
			 * post.addHeader(HTTP.CONTENT_TYPE, APPLICATION_JSON);
			 * post.addHeader("Accept-Charset", "utf-8");
			 * post.addHeader("User-Agent",
			 * "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.160 Safari/537.22"
			 * ); // if(params!=null && params.length()>0)
			 */
			{
				// StringEntity se = new
				// StringEntity(URLEncoder.encode(params,"UTF-8"));
				// StringEntity se = new
				// StringEntity(URLEncoder.encode(params,"UTF-8"));
				// postingString.setContentType(APPLICATION_JSON);
				// postingString.setContentEncoding(new
				// BasicHeader(HTTP.CONTENT_TYPE, APPLICATION_JSON));
				post.setEntity(postingString);

			}
			HttpResponse response = httpclient.execute(post);
			responses.status = response.getStatusLine().getStatusCode();
			if (responses.status == 200) {
				HttpEntity entity = response.getEntity();
				String postResult = EntityUtils.toString(entity, "UTF-8");
				responses.response = postResult;
			}
			// response.get
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responses;
	}

	/**
	 * 通过Post方法获取Entity
	 * 
	 * @param httpclient
	 * @param url
	 * @param params
	 * @return
	 */
	public static CrawlerResponse getPostEntityXXX(HttpClient httpclient, String url, String params) {
		CrawlerResponse responses = new CrawlerResponse();
		try {
			HttpPost post = new HttpPost(url);
			// post.setEntity(new UrlEncodedFormEntity(params));

			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(-1).setConnectionRequestTimeout(-1)
					.setSocketTimeout(-1).build();
			post.setConfig(requestConfig);
			post.addHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded");
			post.addHeader("Accept-Charset", "utf-8");
			post.addHeader("User-Agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.160 Safari/537.22");
			// if(params!=null && params.length()>0)
			{
				StringEntity se = new StringEntity(params);
				se.setContentType(CONTENT_TYPE_TEXT_JSON);
				se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, APPLICATION_JSON));
				post.setEntity(se);

			}
			HttpResponse response = httpclient.execute(post);
			responses.status = response.getStatusLine().getStatusCode();
			if (responses.status == 200) {
				HttpEntity entity = response.getEntity();
				String postResult = EntityUtils.toString(entity, "UTF-8");
				responses.response = postResult;
			}
			// response.get
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responses;
	}

	public static void main(String arg[]) throws InterruptedException {
		// List<NameValuePair> params = new ArrayList<NameValuePair>();
		// params.add(new BasicNameValuePair("username", "shiyongping"));
		// params.add(new BasicNameValuePair("password", "love1123"));
		// System.out.print(NetAccessUtil.getLoginCookie("http://develop.ffan.com/login",
		// params));
		ParamJson jsons = new ParamJson();
		jsons.setDoc("我爱北京天安门上海人民广播电台");
		@SuppressWarnings("unused")
		HttpClient httpclient = new DefaultHttpClient();
		CrawlerResponse response = NetAccessUtil.getPostEntity(httpclient,
				"http://classification.intra.sit.ffan.com/nlp/v1/post/all", JSONObject.toJSONString(jsons));
		System.out.println(response.response);
		if (response != null && response.status == 200 && response.response != null) {
			JSONObject json = JSONObject.parseObject(response.response);
			if (json != null && json.getInteger("status") == 200) {
				NLPToolResult pair = JSONObject.parseObject(json.getString("data"), NLPToolResult.class);
				Map<String, Double> topicMap = new HashMap<String, Double>();
				System.out.println("");
//				for (JSONObject par : pair) {
//					KeyValuePair topic = JSONObject.toJavaObject(par, KeyValuePair.class);
//
//					if (par == null) {
//						break;
//					}
//					 topicMap.put(topic.getKey(), topic.getValue());
//				}

			}
		}
		// HttpClient httpclient = NetAccessUtil.getLoginClient(url, login)
		// String url = "http://develop.ffan.com/#/request_log_rt/1648/day";
		// CrawlerResponse response =
		// LocalNetAccessUtil.getGetEntity(httpclient, url);
		// System.out.println(response.response);

	}
}
