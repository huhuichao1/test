package com.wanda.feeds.ranker.rankers.builder;


import com.wanda.feeds.common.entity.FeedsRecord;
import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.common.entity.base.FeatureType;
import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.access.DocWithFeature;
import com.wanda.feeds.ranker.rankers.features.NLPRankFeature;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by huhuichao on 2017/8/10.
 */

public class NLPFeatureBuilder extends FeatureBuilderBase {

	@Override
	public RankFeature buildFeature(UserProfile userProfile, FeedsRecord doc) {
		NLPRankFeature feature = new NLPRankFeature();
		feature.updateTime = doc.getUpdateTime();
		if (userProfile == null) {
			return feature;
		}

		double[] topicFeature = getDocTopicFeature(doc.getTopic64());
		if (topicFeature != null) {
			feature.featureMap.put(FeatureType.TOPIC64, topicFeature);
		}

		// 添加keyword Feature
		double[] keywordFeature = getDocMapFeature(userProfile.getKeywordPreference(), doc.getKeywords(),
				keyword_vector_size);
		if (null != keywordFeature) {
			feature.featureMap.put(FeatureType.KEYWORDS, keywordFeature);
		}

		// 添加category Feature
		double[] categoryFeature = getDocCategoryFeature(doc.getCategory());
		if (null != categoryFeature) {
			feature.featureMap.put(FeatureType.CATEGORY, categoryFeature);
		}
		double[] features = getFeatuersArrayVector(topicFeature, keywordFeature, categoryFeature);

		feature.features = features;
		return feature;
	}

	/**
	 * 获取用户nlp属性对于doc的feature vector
	 *
	 * @param userPreference
	 *            ,用户nlp属性之一
	 * @param docFeature，doc
	 *            对应的nlp属性
	 * @param featureLength，长度featureLength；
	 * @return
	 */
	public static double[] getDocMapFeature(List<KeyValuePair> userPreference, List<KeyValuePair> docFeature,
											int featureLength) {
		double[] feature = new double[featureLength];
		if (userPreference == null || (userPreference != null && userPreference.size() == 0)) {
			return feature;
		}
		Map<String, Double> docFeatureMap = listConvertMap(docFeature);
		if (docFeature == null || (docFeature != null && docFeature.size() == 0)) {
			return feature;
		}
		int length = userPreference.size() > featureLength ? featureLength : userPreference.size();
		for (int i = 0; i < length; i++) {
			String keyword = userPreference.get(i).getKey();
			feature[i] = docFeatureMap.get(keyword) == null ? 0d : docFeatureMap.get(keyword);
		}
		return feature;
	}

	/**
	 * 这是doc的category向量
	 *
	 * @param docFeature
	 *            ,doc 的feature
	 * @return
	 */
	public static double[] getDocCategoryFeature(List<KeyValuePair> docFeature) {
		double[] feature = new double[categoryMap.size()];

		if (docFeature == null || (docFeature != null && docFeature.size() == 0)) {
			return feature;
		}
		for (KeyValuePair entry : docFeature) {
			if (categoryMap.get(entry.getKey()) == null) {
				continue;
			}
			feature[categoryMap.get(entry.getKey())] = entry.getValue();
		}
		return feature;
	}

	/**
	 * 这是doc的topic向量
	 *
	 * @param docFeature
	 *            ,doc 的feature
	 * @return
	 */
	protected static double[] getDocTopicFeature(List<KeyValuePair> docFeature) {
		double[] feature = new double[topic64_vector_size];

		if (docFeature == null || (docFeature != null && docFeature.size() == 0)) {
			return feature;
		}
		for (KeyValuePair entry : docFeature) {
			if (topic64Map.get(entry.getKey()) == null) {
				continue;
			}
			feature[topic64Map.get(entry.getKey())] = entry.getValue();
		}
		return feature;
	}

	public static Map<String, Double> listConvertMap(List<KeyValuePair> list) {
		if(list==null){
			return null;
		}
		Map<String, Double> map = new HashMap<String, Double>();
		for (KeyValuePair pari : list) {
			map.put(pari.getKey(), pari.getValue());
		}
		return map;
	}

	/**
	 * 把3个数组合并成一个
	 * 
	 * @param topicFeature
	 * @param keywordFeature
	 * @param categoryFeature
	 * @return
	 */
	public static double[] getFeatuersArrayVector(double[] topicFeature, double[] keywordFeature,
			double[] categoryFeature) {
		double[] features = new double[keyword_vector_size + category_vector_size + topic64_vector_size];
		for (int i = 0; i < topicFeature.length; i++) {
			features[i] = topicFeature[i];
		}

		for (int i = 0; i < categoryFeature.length; i++) {
			features[topic64_vector_size + i] = categoryFeature[i];
		}

		if (keywordFeature != null) {
			for (int i = 0; i < keywordFeature.length; i++) {
				features[topic64_vector_size + category_vector_size + i] = keywordFeature[i];
			}
		}

		return features;
	}

	public DocWithFeature addKeywordFeature(UserProfile userProfile, DocWithFeature doc) {
		DocWithFeature ret = doc;
		// 添加keyword Feature
		double[] keywordFeature = getDocMapFeature(userProfile.getKeywordPreference(),
				((DocumentRecord) (doc.doc)).getKeywords(), keyword_vector_size);
		if (null != keywordFeature) {
			ret.feature.featureMap.put(FeatureType.KEYWORDS, keywordFeature);
		}

		for (int i = 0; i < keywordFeature.length; i++) {
			ret.feature.features[topic64_vector_size + category_vector_size + i] = keywordFeature[i];
		}
		return ret;
	}

	public DocWithFeature buildFeature(DocumentRecord doc) {
		// TODO Auto-generated method stub
		DocWithFeature docWithFeature = new DocWithFeature();
		NLPRankFeature feature = new NLPRankFeature();
		feature.updateTime = doc.getUpdateTime();
		feature.isPremium = doc.isPremium();
		feature.premiumScore=doc.getPremiumScore();
		feature.consumeScore=doc.getConsumeScore();
		double[] topicFeature = getDocTopicFeature(doc.getTopic64());
		if (topicFeature != null) {
			feature.featureMap.put(FeatureType.TOPIC64, topicFeature);
		}

		// // 添加keyword Feature
		// double[] keywordFeature =
		// getDocMapFeature(userProfile.getKeywordPreference(),
		// doc.getKeywords(),
		// keyword_vector_size);
		// if (null != keywordFeature) {
		// feature.featureList.put(FeatureType.KEYWORDS, keywordFeature);
		// }

		// 添加category Feature
		double[] categoryFeature = getDocCategoryFeature(doc.getCategory());
		if (null != categoryFeature) {
			feature.featureMap.put(FeatureType.CATEGORY, categoryFeature);
		}
		double[] features = getFeatuersArrayVector(topicFeature, null, categoryFeature);

		feature.features = features;
		docWithFeature.doc = doc;
		docWithFeature.feature = feature;
		return docWithFeature;
	}
}
