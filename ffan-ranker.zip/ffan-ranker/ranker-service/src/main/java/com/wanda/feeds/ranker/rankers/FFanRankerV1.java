package com.wanda.feeds.ranker.rankers;


import com.wanda.feeds.common.entity.*;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.ranker.access.DocWithFeature;
import com.wanda.feeds.ranker.rankers.l3.IL3Ranker;
import com.wanda.feeds.ranker.processer.NLPProcesser;
import com.wanda.feeds.ranker.processer.NormDataProcesser;
import com.wanda.feeds.ranker.rankers.base.Ranker;
import com.wanda.feeds.ranker.rankers.builder.IFeatureBuilder;
import com.wanda.feeds.ranker.rankers.features.NLPRankFeature;
import com.wanda.feeds.ranker.rankers.scorer.IScorer;
import com.wanda.feeds.ranker.rankers.struct.L2RankRecord;
import com.wanda.feeds.ranker.rankers.struct.RankStruct;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by huhuichao on 2017/11/20.
 */
public class FFanRankerV1 extends Ranker {
    protected IScorer iScorer;
    protected IFeatureBuilder userFeatureBuilder;
    protected IFeatureBuilder docFeatureBuilder;
    protected IL3Ranker l3Ranker;


    public FFanRankerV1(String name) {
        super(name);
    }

    @Override
    public DocumentSet ranking(FilterSet result, UserProfile profile) throws Exception {
        DocumentSet documentSet = null;
        try{
            int size=result.getSize();
//            LOGGER.info("ranker：" + name + "执行查询操作，id为:(" + result.toStringTopId(5) + ")");
            Long start=System.currentTimeMillis();

            RankFeature userFeature = getUserFeature(profile);
            List<L2RankRecord> records = new ArrayList<L2RankRecord>(result.getRecords().size());
            for (RecordBase record : result.getRecords()) {
                DocNLPRecord feedsRecord = (DocNLPRecord) record;
                RankFeature docFeature = getDocFeature(profile, feedsRecord,result.isMetric());
                RankStruct struct = new RankStruct(feedsRecord, userFeature, docFeature);
                L2RankRecord rankRecord = struct.calcL2Score(iScorer, result.isExplain());
                records.add(rankRecord);
            }
            Long score=System.currentTimeMillis();

//            LOGGER.info("ranker：计算score得分耗时："+(score-start));
            this.l2sort(records);
            Long l2=System.currentTimeMillis();

//            LOGGER.info("ranker：L2 rank 耗时："+(l2-score));

            List<RankRecord> retRecord = l3Ranker.ranking(records);
            this.sort(retRecord);
//            LOGGER.info("ranker：L3 rank 耗时："+(System.currentTimeMillis()-l2));
            retRecord= retRecord.size()>size?retRecord.subList(0,size):retRecord;
            documentSet = new DocumentSet(retRecord);
//            LOGGER.info(name + "排序后id为:(" + documentSet.toStringTopId(5) + ")");

        }catch (Exception e){
            LOGGER.error("ranker内部异常：", e.getMessage());
            throw e;
        }
        return documentSet;
    }
    protected void l2sort(List<L2RankRecord> records) {
        if (records == null || records.size() < 2) {
            return;
        }
        Collections.sort(records, new Comparator<L2RankRecord>() {
            public int compare(L2RankRecord o1, L2RankRecord o2) {
                if (o1.getScore() > o2.getScore()) {
                    return -1; // 降序
                } else if (o1.getScore() < o2.getScore()) {
                    return 1; // 升序
                } else {
                    return o1.getId().compareTo(o2.getId());
                }
            }
        });
    }

    /**
     * @return
     */
    public RankFeature getUserFeature(UserProfile profile) {
        // System.out.println("userFeatureBuilder内存地址:"+userFeatureBuilder);
        return userFeatureBuilder.buildFeature(profile, null);
    }

    public RankFeature getDocFeature(UserProfile profile, RecordBase base,Boolean isMetric) {
        DocNLPRecord record = (DocNLPRecord) base;
        DocWithFeature doc =isMetric? NormDataProcesser.getFeatureListById(record.getId(), record.getEntryId()): NLPProcesser.getFeatureListById(record.getId(), record.getEntryId());
        doc = docFeatureBuilder.addKeywordFeature(profile, doc);
        NLPRankFeature feature = (NLPRankFeature) doc.feature;
        feature.hotScore = record.getHotScore();
        return feature;
    }


    public IScorer getiScorer() {
        return iScorer;
    }

    public void setiScorer(IScorer iScorer) {
        this.iScorer = iScorer;
    }

    public IFeatureBuilder getUserFeatureBuilder() {
        return userFeatureBuilder;
    }

    public void setUserFeatureBuilder(IFeatureBuilder userFeatureBuilder) {
        this.userFeatureBuilder = userFeatureBuilder;
    }

    public IFeatureBuilder getDocFeatureBuilder() {
        return docFeatureBuilder;
    }

    public void setDocFeatureBuilder(IFeatureBuilder docFeatureBuilder) {
        this.docFeatureBuilder = docFeatureBuilder;
    }

    public IL3Ranker getL3Ranker() {
        return l3Ranker;
    }

    public void setL3Ranker(IL3Ranker l3Ranker) {
        this.l3Ranker = l3Ranker;
    }
}
