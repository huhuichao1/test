package com.wanda.feeds.ranker.processer;


import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.ranker.access.DocWithFeature;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class NormDataProcesser {
	private final static org.slf4j.Logger LOGGER = LoggerFactory.getLogger(NormDataProcesser.class);



	public static Map<String, DocWithFeature> featureMap = new HashMap<String, DocWithFeature>();

	public static DocWithFeature getFeatureListById(String id,String entryId) {
		if (id == null) {
			return null;
		}

		DocWithFeature doc = featureMap.get(id);
		if (doc == null) {
			LOGGER.info("docid="+id+"。没有在缓存中命中，执行默认feature。。。");
			doc = DocWithFeature.getCommonDoc(id,entryId);
		}
		return doc;
	}



	/**
	 *
	 * @param id
	 * @param feature
	 */
	public synchronized static void putRankFeature(String id, RankFeature feature, RecordBase record) {
		DocWithFeature doc = new DocWithFeature();
		doc.doc = record;
		doc.feature = feature;
		featureMap.put(id, doc);
	}

	/**
	 * 
	 * @param id
	 * @param
	 */
	public synchronized static void putRankFeature(String id, DocWithFeature doc) {
		if(featureMap.get(id)!=null){
			LOGGER.info("检测到缓存数据已有,id："+id+";更新缓存doc。。");
		}
		featureMap.put(id, doc);
	}

}
