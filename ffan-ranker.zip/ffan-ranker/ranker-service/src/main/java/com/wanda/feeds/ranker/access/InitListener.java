package com.wanda.feeds.ranker.access;

import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.common.utils.io.FileOperater;
import com.wanda.feeds.common.utils.io.MyCallBack;
import com.wanda.feeds.ranker.rankers.builder.NLPFeatureBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class InitListener {

	private final static Logger LOGGER = LoggerFactory.getLogger(InitListener.class);

	// public static ThreadPoolTaskExecutor threadPool;
	public static Properties esProp;

	public static double[] defaultTopic64Feature = new double[64];
	public static double[] defaultCategoryFeature;


	static  {
		// defaultCategoryFeature =
		esProp = new Properties();
		try {
			InputStream inStream = InitListener.class.getClassLoader().getResourceAsStream("elasticsearch.properties");
			esProp.load(inStream);// 将属性文件流装载到Properties对象中

			/**
			 * 读取默认topic64 feature
			 */
//			inStream=new FileInputStream("config/topic_feature");
			inStream = InitListener.class.getClassLoader().getResourceAsStream("topic_feature");
			MyCallBack callback = new MyCallBack() {

				@Override
				public void operation(String string, Object object) {
					String[] strs = string.split("\t");
					defaultTopic64Feature[Integer.valueOf(strs[0])] = Double.valueOf(strs[1]);
				}

			};
			LOGGER.info("init default topic64 feature success，defaultTopic64Feature："+Arrays.toString(defaultTopic64Feature));
			FileOperater.readline(inStream, callback);
			/**
			 * 读取默认category feature
			 */
//			inStream=new FileInputStream("config/category_feature");

			inStream = InitListener.class.getClassLoader().getResourceAsStream("category_feature");

			List<KeyValuePair> docFeature = new ArrayList<KeyValuePair>();
			callback = new MyCallBack() {

				@Override
				public void operation(String string, Object object) {
					String[] strs = string.split("\t");
					KeyValuePair pair = new KeyValuePair();
					pair.setKey(strs[0]);
					pair.setValue(Double.valueOf(strs[1]));
					docFeature.add(pair);
					// defaultCategoryFeature[Integer.valueOf(strs[0])] =
					// Double.valueOf(strs[1]);
				}

			};
			FileOperater.readline(inStream, callback);
			defaultCategoryFeature = NLPFeatureBuilder.getDocCategoryFeature(docFeature);

			inStream.close();
			LOGGER.info("init default category feature success，defaultTopic64Feature："+ Arrays.toString(defaultCategoryFeature));

		} catch (Exception e) {
			System.out.println("init error");
			e.printStackTrace();
			System.exit(1);
		}

	}


}
