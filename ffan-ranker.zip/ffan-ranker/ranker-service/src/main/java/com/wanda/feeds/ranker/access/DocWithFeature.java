package com.wanda.feeds.ranker.access;


import com.wanda.feeds.common.entity.base.FeatureType;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.rankers.builder.NLPFeatureBuilder;
import com.wanda.feeds.ranker.rankers.features.NLPRankFeature;

/**
 * Created by huhuichao on 2017/11/10.
 */
public class DocWithFeature {

        public RankFeature feature;
        public RecordBase doc;

        // public DocWithFeature() {
        // feature = new NLPRankFeature();
        // doc = new DocumentRecord();
        // }

        /**
         * 获取默认的DocWhichFeature
         * @param id
         * @return
         */
        public static DocWithFeature getCommonDoc(String id, String entryId) {
            DocWithFeature doc = new DocWithFeature();
            NLPRankFeature feature = new NLPRankFeature();
            DocumentRecord document = new DocumentRecord();
            feature.features = NLPFeatureBuilder.getFeatuersArrayVector(InitListener.defaultTopic64Feature, null,
                    InitListener.defaultCategoryFeature);
            feature.featureMap.put(FeatureType.CATEGORY, InitListener.defaultCategoryFeature);
            feature.featureMap.put(FeatureType.TOPIC64, InitListener.defaultTopic64Feature);
            feature.updateTime=System.currentTimeMillis();
            document.setId(id);
            document.setEntryId(entryId);
            doc.doc = document;
            doc.feature = feature;
            return doc;

    }
}
