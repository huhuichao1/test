package com.wanda.feeds.ranker.controller;

import com.alibaba.fastjson.JSONObject;
import com.wanda.feeds.common.entity.*;
import com.wanda.feeds.common.utils.io.FileOperater;
import com.wanda.feeds.ranker.processer.NLPProcesser;
import com.wanda.feeds.ranker.rankers.base.RankerFactory;
import com.wanda.feeds.ranker.rest.RankerRequest;
import com.wanda.feeds.ranker.utils.NetAccessUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huhuichao on 2017/11/22.
 */
@RestController
@RequestMapping("/v1/common")
@Api(value = "RankerController", description = "ranker接口")
public class RankerController {

    private static final Logger LOGGER = LoggerFactory.getLogger(RankerController.class);


    static UserProfile userProfile = new UserProfile();
    static FilterSet filterSet = null;

    static {
        InputStream is = RankerController.class.getClassLoader().getResourceAsStream("101000000070.txt");
        String userJson = FileOperater.readFile(is);
        userProfile = JSONObject.parseObject(userJson, UserProfile.class);


    }

    public void getFilterSet() {
        filterSet = new FilterSet();
        List<DocNLPRecord> list = new ArrayList<DocNLPRecord>();
        int i = 0;
        for (String id : NLPProcesser.featureMap.keySet()) {
            i++;
            DocNLPRecord record = new DocNLPRecord();
            record.setId(id);
            list.add(record);
            if (i == 500) {
                break;
            }
        }
        filterSet.setNLPRecords(list);
        filterSet.setMetric(false);
    }


    @RequestMapping(value = "/rank/notIo/test", method = {RequestMethod.GET}, produces = {"application/json; charset=UTF-8"})
    @ApiOperation(value = "排序结果集", notes = "排序结果集")
    public List<RankRecord> rank() throws Exception {
        if (filterSet == null) {
            getFilterSet();
        }
        Long start = System.currentTimeMillis();
        List<RankRecord> list = RankerFactory.getRanker("ffanRankerV1").ranking(filterSet, userProfile).getRecords();
        LOGGER.info("ranking 过程耗时：" + (System.currentTimeMillis() - start));
        return list;
    }

    @RequestMapping(value = "/ranking/post", method = {RequestMethod.POST}, produces = {"application/json; charset=UTF-8"})
    @ApiOperation(value = "排序结果集", notes = "排序结果集")
    public List<RankRecord> ranking(@Validated @RequestBody JSONObject obj) throws Exception {
        String rankerName = obj.getString("rankerName");
        UserProfile userProfile = obj.getObject("userProfile", UserProfile.class);
        FilterSet filterSet = obj.getObject("filterSet", FilterSet.class);
//        LOGGER.info("解析json过程耗时：" + (json - start));
        List<RankRecord> ret = RankerFactory.getRanker(rankerName).ranking(filterSet, userProfile).getRecords();
//        LOGGER.info("ranking 过程耗时：" + (System.currentTimeMillis() - json));
        return ret;
    }


    @RequestMapping(value = "/ranking/post/test", method = {RequestMethod.GET}, produces = {"application/json; charset=UTF-8"})
    public List<RankRecord> ranking(int size) throws Exception {
        String url = "http://localhost:10000/v1/common/ranking/post";
        InputStream is = RankerController.class.getClassLoader().getResourceAsStream("101000000070.txt");
        String userJson = FileOperater.readFile(is);

        UserProfile userProfile = JSONObject.parseObject(userJson, UserProfile.class);

        FilterSet filterSet = new FilterSet();
        List<DocNLPRecord> list = new ArrayList<DocNLPRecord>();
        int i = 0;
        for (String id : NLPProcesser.featureMap.keySet()) {
            i++;
            DocNLPRecord record = new DocNLPRecord();
            record.setId(id);
            list.add(record);
            if (i == size) {
                break;
            }
        }
        filterSet.setNLPRecords(list);
        filterSet.setMetric(false);

        RankerRequest rankerRequest = new RankerRequest(userProfile, filterSet, "ffanRankerV1");
        @SuppressWarnings("unused")
        HttpClient httpclient = new DefaultHttpClient();
        NetAccessUtil.CrawlerResponse response = NetAccessUtil.getPostEntity(httpclient,
                url, rankerRequest.toString());
        if (response.status == 200) {
            String docJson = JSONObject.toJSONString(response.response);
            List<RankRecord> rankRecords = JSONObject.parseArray(docJson, RankRecord.class);
            return rankRecords;
        }
//        String boby = HttpClientUtil.post(url, JSONUtil.bean2JSONObject());
//        RestResponse response = JSONObject.parseObject(boby, RestResponse.class);
//        String docJson = JSONObject.toJSONString(response.getData());
//        DocumentSet set = JSONObject.parseObject(docJson, DocumentSet.class);
        return null;
    }

    @RequestMapping(value = "/rank/post", method = {RequestMethod.POST}, produces = {"application/json; charset=UTF-8"})
    @ApiOperation(value = "排序结果集", notes = "排序结果集")
    public DocumentSet rank(@Validated @RequestBody JSONObject obj) throws Exception {
        String rankerName = obj.getString("rankerName");
        UserProfile userProfile = obj.getObject("userProfile", UserProfile.class);
        FilterSet filterSet = obj.getObject("filterSet", FilterSet.class);
//        LOGGER.info("解析json过程耗时：" + (json - start));
        return RankerFactory.getRanker(rankerName).ranking(filterSet, userProfile);
    }


}
