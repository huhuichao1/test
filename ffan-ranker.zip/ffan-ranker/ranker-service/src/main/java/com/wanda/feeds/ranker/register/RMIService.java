package com.wanda.feeds.ranker.register;

import com.wanda.feeds.ranker.handler.IService;
import com.wanda.feeds.ranker.handler.RankerService;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.ServerSocket;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.RMIServerSocketFactory;

public class RMIService {

    private static Logger logger = Logger.getLogger(RMIService.class);

    public static class SMRMISocket implements RMIServerSocketFactory {
        int port;
        public SMRMISocket(int port){
            this.port=port;
        }
        public ServerSocket createServerSocket(int port) throws IOException {
            port=this.port;
            return new ServerSocket(port);
        }

    }

    public static void createService(int port, String name,int socketport) {
        try {
            RMIServerSocketFactory factory = new SMRMISocket(socketport);
            IService service = new RankerService(factory,name);
            if(!isUsedPort(port)){
                LocateRegistry.createRegistry(port);
            }
            Naming.rebind("rmi://localhost:" + port + "/" + name, service);
            logger.info("Service han been started on port=" + port + ",name=" + name+"..");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean isUsedPort(int port){
        try{
            Registry registry = LocateRegistry.getRegistry(port);
            registry.list();
            return true;
        }catch (Exception e){
            //LocateRegistry.createRegistry(port);
        }
        return false;
    }
}
