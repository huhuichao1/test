package com.wanda.feeds.ranker.rankers.features;

import com.wanda.feeds.common.entity.base.RankFeature;

public class NLPPlusFeature extends RankFeature {
	
	public double timeScore; // 时间得分 【ok】     ----（已有值）0-1 归一化处理
	public double hotScore; // hotScore得分 【ok】    ---（已有值）召回传入
	public int isPremium; // 是不是优质文章 0：一般文章 1：优质文章 【ok】   ----（已有值es）
	public double topic64Score;// 积累topic 【ok】		----可以算（通过user）
	public double categoryScore;// 类别积累得分 【ok】			----可以算（通过user）
	
	public double keywordScore;// keyword积累得分 【ok】		----可以算（通过user）
	public int articleLen;// 文档长度 【ok】		----（已有值es length）
	public int mediaType;// 文档类型 0:普通文章 1:图集 3:短视频 【ok】   ----（内容平台提供）
	public int authorScore;// 作者评分 [NG]		
	public int pv;// pv量 [NG]
	
	public int clickCount;// clickcount [NG]
	public int fCCount;// 转发和搜藏数 [NG]
	public int likes;// 点赞数 [NG]
	public int cityRelevance;// 0：表示相关 1：表示不想关 [NG]
	public double categorySim;// 余弦相似度 【ok】      ----（文档得分）
	
	public double topic64Sim;// topic64余弦相似度 【ok】     ----（文档得分）
	public double imageCount;// 图的数量 【ok】           ----（内容平台提供）
	public double imageSize;// 图的大小 [NG]
	public double typesettingScore;// 排版得分 [NG]
	public double premiumScore;

	// public double emotion;//情感得分 [NG]

	/**
	 * 结合NLP两个重要feature：topic64 category13 一共19+64+13 = 96个特征值 可以用于CTR预估和排序算法
	 * 
	 * 其中CTR需要考虑的东西更多，包括： 前后category组合 排列位置 图的数量等
	 * 
	 * 使用此类打分器应该充分考虑category连续排版引起的惩罚因子
	 * 
	 */
	public double[] nlpPlusFeatureVector(double []docTopic64,double[]docCategory){
		double[] features=new double[96];
		int index=docTopic64.length;
		for(int i=0;i<index;i++){
			features[i]=docTopic64[i];
		}
		for(int i=0;i<docCategory.length;i++){
			features[i]=docCategory[i+index];
		}
		index=index+docCategory.length;
		double[] plus=createNLPPlusVector(this);
		for(int i=0;i<plus.length;i++){
			features[i]=plus[i+index];
		}
		return features;
	}
	
	/**
	 * 把NLPPlusFeature 生成一个19位的向量
	 * @param feature
	 * @return
	 */
	public double[] createNLPPlusVector(NLPPlusFeature feature){
		double[] features=new double[19];
		features[0]=feature.timeScore;
		features[1]=feature.hotScore;
		features[2]=feature.isPremium;
		features[3]=feature.topic64Score;
		features[4]=feature.categoryScore;
		
		features[5]=feature.keywordScore;
		features[6]=feature.articleLen;
		features[7]=feature.mediaType;
		features[8]=feature.authorScore;
		features[9]=feature.pv;
		
		features[10]=feature.clickCount;
		features[11]=feature.fCCount;
		features[12]=feature.likes;
		features[13]=feature.cityRelevance;
		features[14]=feature.hotScore;
		
		features[15]=feature.topic64Sim;
		features[16]=feature.imageCount;
		features[17]=feature.imageSize;
		features[18]=feature.typesettingScore;
		return features;
	}

}
