package com.wanda.feeds.ranker.rankers.features;


import com.wanda.feeds.common.entity.base.RankFeature;

/**
 * Created by huichao on 2017/8/10.
 */
public class NLPRankFeature extends RankFeature {

	public Long updateTime;
	public double hotScore;
	public double premiumScore;
	public boolean isPremium=false;
	public double consumeScore;

}
