package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/9/25.
 */
public class CategoryScore extends  BoostScore{

   public Double category_feature_score;

    public CategoryFeature categoryFeature;

    public static class CategoryFeature{

        public String user_category_feature;
        public String doc_category_feature;

    }

}
