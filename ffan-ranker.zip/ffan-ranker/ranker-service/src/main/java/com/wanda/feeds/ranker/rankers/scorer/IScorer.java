package com.wanda.feeds.ranker.rankers.scorer;


import com.wanda.feeds.common.entity.base.RankFeature;

public interface IScorer {

	Score calcScore(RankFeature userFeature, RankFeature docFeature,Boolean explain);
}
