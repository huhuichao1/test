package com.wanda.feeds.ranker.handler;

import com.wanda.feeds.common.entity.DocumentSet;
import com.wanda.feeds.common.entity.FilterSet;
import com.wanda.feeds.common.entity.UserProfile;
import com.wanda.feeds.ranker.rankers.base.RankerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;

/**
 * Created by huhuichao on 2017/7/5.
 */
public class RankerService extends UnicastRemoteObject implements IService {

    private final static Logger LOGGER = LoggerFactory.getLogger(RankerService.class);

    private String name;

    public RankerService() throws RemoteException {
        super();

    }

    public RankerService(RMIServerSocketFactory s, String name) throws RemoteException {
        super(0, null, s);
        this.name = name;

    }

    public RankerService(int port, RMIClientSocketFactory rcf) throws RemoteException {
        super(port, rcf, null);

    }

    @Override
    public DocumentSet ranking(FilterSet filterSet, UserProfile profle) throws Exception {
        long start = System.currentTimeMillis();
        DocumentSet ret = RankerFactory.getRanker(name).ranking(filterSet, profle);
        ret.setTime(System.currentTimeMillis() - start);
        LOGGER.info(name+"cost time= " + (System.currentTimeMillis() - start) + " ms");
        return ret;
    }


}
