package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/9/25.
 */
public class Topic64Score extends BoostScore {

   public Double topic64_feature_score;
    public Topic64Feature topic64Feature;

    public static class Topic64Feature{

        public String user_topic64_feature;
        public String doc_topic64_feature;

    }

}
