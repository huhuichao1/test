package com.wanda.feeds.ranker.handler;


import java.rmi.Remote;

import com.wanda.feeds.common.entity.DocumentSet;
import com.wanda.feeds.common.entity.FilterSet;
import com.wanda.feeds.common.entity.UserProfile;

public interface IService extends Remote{
	

	public DocumentSet ranking(FilterSet filterSet, UserProfile profle) throws Exception;

}
