package com.wanda.feeds.ranker.rankers.scorer;

import com.wanda.feeds.common.entity.base.FeatureType;
import com.wanda.feeds.common.entity.base.RankFeature;
import org.jblas.DoubleMatrix;

import java.util.Map;

public class DocSimScorer implements IScorer {

	public static final double boost_keyword_feature_score = 0.15;
	public static final double boost_category_feature_score = 0.50;
	public static final double boost_topic64_feature_score = 0.35;

	public Score calcScore(RankFeature source, RankFeature dist,Boolean explain) {
		Score ret = new Score();
		double score = 0d;
		double keyword_feature_score = 0d;
		double category_feature_score = 0d;
		double topic64_feature_score = 0d;
//		NLPRankFeature nlpRankFeature = (NLPRankFeature) dist;

		Map<FeatureType, double[]> sourceFeatureMap = source.featureMap;
		Map<FeatureType, double[]> distFeatureMap = dist.featureMap;
		if (sourceFeatureMap.size() != 0 && distFeatureMap.size() != 0) {
			if (sourceFeatureMap.get(FeatureType.KEYWORDS) != null
					&& distFeatureMap.get(FeatureType.KEYWORDS) != null) {
				double[] userKeywordFeature = sourceFeatureMap.get(FeatureType.KEYWORDS);
				double[] docKeywordFeature = distFeatureMap.get(FeatureType.KEYWORDS);
				keyword_feature_score = cosineSimilarity(userKeywordFeature, docKeywordFeature);
			}

			if (sourceFeatureMap.get(FeatureType.CATEGORY) != null
					&& distFeatureMap.get(FeatureType.CATEGORY) != null) {
				double[] userCategoryFeature = sourceFeatureMap.get(FeatureType.CATEGORY);
				double[] docCategoryFeature = distFeatureMap.get(FeatureType.CATEGORY);
				category_feature_score = cosineSimilarity(userCategoryFeature, docCategoryFeature);
			}

			if (sourceFeatureMap.get(FeatureType.TOPIC64) != null && distFeatureMap.get(FeatureType.TOPIC64) != null) {
				double[] userTopic64Feature = sourceFeatureMap.get(FeatureType.TOPIC64);
				double[] docTopic64Feature = distFeatureMap.get(FeatureType.TOPIC64);
				topic64_feature_score = cosineSimilarity(userTopic64Feature, docTopic64Feature);
			}
		}
		score = keyword_feature_score * boost_keyword_feature_score
				+ category_feature_score * boost_category_feature_score
				+ topic64_feature_score * boost_topic64_feature_score;
		ret.setScore(score);
		// ret.setExplain(explain(source, nlpRankFeature, score, time_score,
		// keyword_feature_score, category_feature_score,
		// topic64_feature_score));
		return ret;
	}

	/**
	 * 计算余弦相似度 长度必须一样
	 *
	 * @param v1
	 * @param v2
	 * @return
	 */
	public Double cosineSimilarity(double[] v1, double[] v2) {
		DoubleMatrix factorVector1 = new DoubleMatrix(v1);
		DoubleMatrix factorVector2 = new DoubleMatrix(v2);

		double norm1 = factorVector1.norm2(); // 在线性代数里面
												// norm函数是一种可以在空间向量里面对向量赋予长度和大小的函数
		double norm2 = factorVector2.norm2();
		if (norm1 < 0.000001 || norm2 < 0.000001) {
			return 0.0;
		}
		Double sim = factorVector1.dot(factorVector2) / (norm1 * norm2);
		return sim;// cosineSimilarity(factorVector,
		// itemVector);
	}

}
