package com.wanda.feeds.ranker.rankers.base;


import com.wanda.feeds.common.entity.DocumentSet;
import com.wanda.feeds.common.entity.FilterSet;
import com.wanda.feeds.common.entity.RankRecord;
import com.wanda.feeds.common.entity.UserProfile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 *
 * @author huhuichao
 * This class implements the generic Ranker interface. Each ranking algorithm implemented has to extend this class.
 */
public abstract class Ranker {
	protected final static Logger LOGGER = LoggerFactory.getLogger(Ranker.class);
	public static boolean verbose = true;
	public String name;


	public Ranker(String name) {
		this.name = name;
	}


	public abstract DocumentSet ranking(FilterSet result, UserProfile profile) throws Exception;

	protected void sort(List<RankRecord> records) {
		if (records == null || records.size() < 2) {
			return;
		}
		Collections.sort(records, new Comparator<RankRecord>() {
			public int compare(RankRecord o1, RankRecord o2) {
				if (o1.getScore() > o2.getScore()) {
					return -1; // 降序
				} else if (o1.getScore() < o2.getScore()) {
					return 1; // 升序
				} else {
					return o1.getId().compareTo(o2.getId());
				}
			}
		});
	}





	public void PRINT(String msg)
	{
		if(verbose)
			System.out.print(msg);
	}
	public void PRINTLN(String msg)
	{
		if(verbose)
			LOGGER.info(msg);
	}
	public void PRINT(int[] len, String[] msgs)
	{
		if(verbose)
		{
			for(int i=0;i<msgs.length;i++)
			{
				String msg = msgs[i];
				if(msg.length() > len[i])
					msg = msg.substring(0, len[i]);
				else
					while(msg.length() < len[i])
						msg += " ";
				System.out.print(msg + " | ");
			}
		}
	}
	public void PRINTLN(int[] len, String[] msgs)
	{
		PRINT(len, msgs);
		PRINTLN("");
	}
	public void PRINTTIME()
	{
		DateFormat dateFormat = new SimpleDateFormat("MM/dd HH:mm:ss");
		Date date = new Date();
		LOGGER.info(dateFormat.format(date));
	}
	public void PRINT_MEMORY_USAGE()
	{
		LOGGER.info("***** " + Runtime.getRuntime().freeMemory() + " / " + Runtime.getRuntime().maxMemory());
	}

	protected void copy(double[] source, double[] target)
	{
		for(int j=0;j<source.length;j++)
			target[j] = source[j];
	}
	/**
	 * HAVE TO BE OVER-RIDDEN IN SUB-CLASSES
	 */
	public void init()
	{
	}
	public void learn()
	{
	}
//	public double eval(DataPoint p)
//	{
//		return -1.0;
//	}
	public Ranker clone()
	{
		return null;
	}
	public String toString()
	{
		return "[Not yet implemented]";
	}
	public String model()
	{
		return "[Not yet implemented]";
	}
	public void load(String fn)
	{
	}
	public void printParameters()
	{
	}
	public String name()
	{
		return "";
	}
}
