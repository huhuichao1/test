package com.wanda.feeds.ranker.enums;

/**
 * Created by huhuichao on 2017/10/19.
 */
public enum AccessRankerModeEnum {

    HTTP,TCP;
}
