package com.wanda.feeds.ranker.rankers.l3;

import com.wanda.feeds.common.entity.RankRecord;
import com.wanda.feeds.ranker.rankers.scorer.IScorer;
import com.wanda.feeds.ranker.rankers.scorer.Score;
import com.wanda.feeds.ranker.rankers.struct.L2RankRecord;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class L3Ranker implements IL3Ranker {

	static Logger logger = Logger.getLogger(L3Ranker.class);
	IScorer scorer;
	static double Threshold = 0.8;
	static double PunishmentWeight = 0.50;

	static double L2Threshold = 0.7;
	static double L2PunishmentWeight = 0.25;
	static int size = 40;

	public L3Ranker(IScorer scorer) {
		this.scorer = scorer;
	}

	@Override
	public List<RankRecord> ranking(List<L2RankRecord> records) throws Exception {
		// TODO Auto-generated method stub
		if (scorer == null) {
			throw new NullPointerException();
		}

		List<RankRecord> ret = new ArrayList<RankRecord>();
		if (records.size() <= 3) {
			for (L2RankRecord l2record : records) {
				RankRecord record = new RankRecord(l2record.getId(),l2record.getEntryId(), l2record.getScore(), l2record.getExplain());
				ret.add(record);
			}
			return ret;
		}

		List<L2RankRecord> recordBuff = new ArrayList<L2RankRecord>();
		// 前两条不参与权重排序
		recordBuff.addAll(records.subList(0, 2));
		size = size<records.size()?size:records.size();
		List<L2RankRecord> subRecordList = records.subList(2, size);
		for (L2RankRecord rec : subRecordList) {
			double simScore = this.getMaxSimScore(rec, recordBuff);
			if (simScore < L2Threshold) {
				recordBuff.add(rec);
//				System.out.println("max_sim_doc_score=" + simScore);
			} else {

				double punsh = PunishmentWeight;
				if (simScore < Threshold) {
					punsh = L2PunishmentWeight;
				}
				double simSco = punsh * simScore;
				double l3Score = rec.getScore() - simSco;
				rec.setScore(l3Score);
				rec.setExplain(rec.getExplain() + "\n(max_sim_doc_score=" + simScore + " * weigth=" + punsh
						+ "; punishment_score=-" + simSco + "); L3 score=" + l3Score + "\n\t");
				recordBuff.add(rec);
			}
		}

		return list(recordBuff);
	}

	private List<RankRecord> list(List<L2RankRecord> records) {
		List<RankRecord> ret = new ArrayList<RankRecord>();
		for (L2RankRecord l2record : records) {
			RankRecord record = new RankRecord(l2record.getId(),l2record.getEntryId(), l2record.getScore(), l2record.getExplain());
			ret.add(record);
		}
		return ret;

	}

	/**
	 * 和第一条开始比较相关性。
	 * 相关性大于0.8的返回 break。
	 * @param record
	 * @param records 自增的
	 * @return 相关性大于0.8的那个值
	 */
	private double getMaxSimScore(L2RankRecord record, List<L2RankRecord> records) {
		double ret = 0d;

		for (L2RankRecord rec : records) {
			Score score = scorer.calcScore(record.getDocFeature(), rec.getDocFeature(),false);
			ret = ret > score.getScore() ? ret : score.getScore();
			if (ret >= Threshold) {
				break;
			}
		}
		return ret;
	}
}
