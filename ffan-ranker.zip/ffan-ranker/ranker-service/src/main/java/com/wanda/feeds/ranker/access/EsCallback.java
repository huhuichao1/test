package com.wanda.feeds.ranker.access;


import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.processer.NLPProcesser;
import com.wanda.feeds.ranker.rankers.builder.IFeatureBuilder;

public class EsCallback implements SQLCallback {

	IFeatureBuilder buidler;

	public Object callback(RecordBase entity) {

		DocumentRecord record = (DocumentRecord) entity;
		DocWithFeature doc = buidler.buildFeature(record);
		NLPProcesser.putRankFeature(record.getId(), doc);
		// TODO Auto-generated method stub
		return null;
	}

	public EsCallback(IFeatureBuilder buidler) {
		this.buidler = buidler;

	}

}
