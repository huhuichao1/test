package com.wanda.feeds.ranker.rest;

import org.hibernate.validator.constraints.NotBlank;

/**
 * 请求参数基类
 */
public abstract class BaseRequest {


}
