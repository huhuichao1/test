package com.wanda.feeds.ranker.access;

import com.wanda.feeds.common.utils.date.TimeFormat;
import com.wanda.feeds.ranker.processer.NLPProcesser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Timer;
import java.util.TimerTask;

public class TimeTask {
    private final static Logger LOGGER = LoggerFactory.getLogger(TimeTask.class);

    public static final int STEP = 5;
    private static Timer timer = new Timer();
    public static int MINUTE = 1000 * 60;// 5分钟更新一次
    private static String time = "20170101000000";



    /**
     * 定时任务
     */
    public void time(AssociationAction action) {
        timer.schedule(new TimerTask() {
            public void run() {
                try {
                    int size= NLPProcesser.featureMap.size();
                    String timestemp = TimeFormat.currentTimeDate14();
                    //每天2点跑一次
                    if (timestemp.substring(8).startsWith("020") && Integer.valueOf(timestemp.substring(11, 12)) / STEP == 0) {
                        time = "20170101000000";
                        LOGGER.info(time + ": 全量更新。。。。");
                    } else {
                        LOGGER.info(time + ": 自动更新。。。。");
                    }
                    String currentTime = TimeFormat.currentTimeDate14();

                    action.accessRecordByTime(time);
                    LOGGER.info("rankerService 缓存data feature 数据总量："+ NLPProcesser.featureMap.size()+";新增数据 "+ (NLPProcesser.featureMap.size()-size)+" 条；");

                    time = currentTime;
                } catch (Exception e) {
                    LOGGER.error("time定时器执行异常：", e);
                }

            }
        }, 0, STEP * MINUTE);

    }
}
