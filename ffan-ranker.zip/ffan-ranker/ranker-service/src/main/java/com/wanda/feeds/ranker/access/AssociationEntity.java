package com.wanda.feeds.ranker.access;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.wanda.feeds.common.entity.base.CommonEntityBase;
import com.wanda.feeds.common.entity.base.KeyValuePair;

public class AssociationEntity extends CommonEntityBase {

	private static final long serialVersionUID = 1L;

	public List<KeyValuePair> assoList = new ArrayList<KeyValuePair>();
	public Set<String> set = new HashSet<String>();

	public int MAX_COUNT = 100;

	@Override
	public Object toJavaObjectFromJson(String Json) {
		// TODO Auto-generated method stub
		return null;
	}

	private void sort() {
		Collections.sort(assoList, new Comparator<KeyValuePair>() {
			public int compare(KeyValuePair a, KeyValuePair b) {
				if (a.getValue() > b.getValue()) {
					return -1;
				} else if (a.getValue() < b.getValue()) {
					return 1;
				}
				return 0;
			}
		});
	}

	public void add(KeyValuePair acc) {
		if (set.contains(acc.getKey())) {
			return;
		}

		int size = assoList.size();
		if (MAX_COUNT >= size) {
			assoList.add(acc);
			set.add(acc.getKey());
		}
		if (size > 0) {

			if (assoList.get(size - 1).getValue() < acc.getValue()) {
				sort();
			}
			if (size == MAX_COUNT) {
				set.remove(assoList.get(size).getKey());
				assoList.remove(size);
			}
		}
	}

}
