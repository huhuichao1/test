package com.wanda.feeds.ranker;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * @author huangzhiqiang
 */
@SpringBootApplication
public class FAApplication extends SpringBootServletInitializer implements ApplicationRunner {

    public static void main(String[] args) {
        SpringApplication.run(FAApplication.class, args);
    } 

    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println("==========Wanda FFan RankerService Startup Success===========");
    }
}
