package com.wanda.feeds.ranker.rankers.struct;


import com.wanda.feeds.common.entity.DocNLPRecord;
import com.wanda.feeds.common.entity.FeedsRecord;
import com.wanda.feeds.common.entity.RankRecord;
import com.wanda.feeds.common.entity.base.RankFeature;
import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.ranker.rankers.scorer.IScorer;
import com.wanda.feeds.ranker.rankers.scorer.Score;

public class RankStruct {

	private RecordBase record;
	private RankFeature userFeature;
	private RankFeature docFeature;


	public RankStruct(FeedsRecord record, RankFeature userFeature, RankFeature docFeature){
		this.record=record;
		this.userFeature=userFeature;
		this.docFeature=docFeature;

	}
	public RankStruct(DocNLPRecord record, RankFeature userFeature, RankFeature docFeature){
		this.record=record;
		this.userFeature=userFeature;
		this.docFeature=docFeature;

	}
	public RankRecord calcRandomScore(IScorer scorer, boolean isExplain){
		Score score = scorer.calcScore(userFeature,docFeature,isExplain);
		if(isExplain){
			return new RankRecord(record.getId(),record.getEntryId(),score.getScore(),"random");
		}else{
			return new RankRecord(record.getId(),score.getScore());
		}
	}

	public RankRecord calcScore(IScorer scorer,boolean isExplain){
		Score score = scorer.calcScore(userFeature,docFeature,isExplain);
		if(isExplain){
			return new RankRecord(record.getId(),record.getEntryId(),score.getScore(),score.getExplain());
		}else{
			return new RankRecord(record.getId(),score.getScore());
		}
	}

	
	public L2RankRecord calcL2Score(IScorer scorer,boolean isExplain){
		Score score = scorer.calcScore(userFeature,docFeature,isExplain);
		if(isExplain){
			return new L2RankRecord(this.docFeature,record.getId(),record.getEntryId(),score.getScore(),score.getExplain());
		}else{
			return new L2RankRecord(this.docFeature,record.getId(),record.getEntryId(),score.getScore());
		}
	}




}
