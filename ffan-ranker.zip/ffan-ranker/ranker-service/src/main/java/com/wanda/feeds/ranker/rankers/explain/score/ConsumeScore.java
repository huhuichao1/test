package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/10/26.
 */
public class ConsumeScore extends BoostScore{

    public Double consume_score;
}
