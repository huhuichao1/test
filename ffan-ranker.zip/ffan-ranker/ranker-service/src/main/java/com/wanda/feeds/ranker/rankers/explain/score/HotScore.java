package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/9/26.
 */
public class HotScore extends BoostScore{

    public  Double hot_score;
}
