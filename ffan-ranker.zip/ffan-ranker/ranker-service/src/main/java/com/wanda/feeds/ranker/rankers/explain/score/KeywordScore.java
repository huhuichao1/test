package com.wanda.feeds.ranker.rankers.explain.score;

/**
 * Created by huhuichao on 2017/9/25.
 */
public class KeywordScore extends BoostScore {

    public Double keyword_feature_score;
    public KeywordFeature keywordFeature;

    public static class KeywordFeature {

        public String user_keyword_feature;
        public String doc_keyword_feature;

    }

}
