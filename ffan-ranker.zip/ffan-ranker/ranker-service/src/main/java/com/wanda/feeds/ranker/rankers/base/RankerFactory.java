package com.wanda.feeds.ranker.rankers.base;

import com.wanda.feeds.ranker.rankers.l3.L3Ranker;
import com.wanda.feeds.ranker.rankers.FFanRankerV1;
import com.wanda.feeds.ranker.rankers.builder.IFeatureBuilder;
import com.wanda.feeds.ranker.rankers.builder.NLPFeatureBuilder;
import com.wanda.feeds.ranker.rankers.builder.UserFeatureBuilder;
import com.wanda.feeds.ranker.rankers.scorer.DocSimScorer;
import com.wanda.feeds.ranker.rankers.scorer.IScorer;
import com.wanda.feeds.ranker.rankers.scorer.NLPFeatureScorerV1;

/**
 * ranker工厂类
 * @author huhuichao
 *
 */
public class RankerFactory {

	/**
	 * 打分器
	 */
	private static IScorer docSimScorer=new DocSimScorer();
	private static IScorer nlpFeatureScorerV1=new NLPFeatureScorerV1();


	/**
	 * builder 构建器
	 */
	private static IFeatureBuilder  userFeatureBuilder=new UserFeatureBuilder();
	private static IFeatureBuilder  docFeatureBuilder=new NLPFeatureBuilder();


	/**
	 * ranker
	 */
	public static FFanRankerV1 ffanRankerV1=new FFanRankerV1("ffanRankerV1");


	static {

		//初始化-组装 ranker配置

		/*********************nlpRankerV1*******************************/

		ffanRankerV1.setL3Ranker(new L3Ranker(docSimScorer));
		ffanRankerV1.setiScorer(nlpFeatureScorerV1);
		ffanRankerV1.setUserFeatureBuilder(userFeatureBuilder);
		ffanRankerV1.setDocFeatureBuilder(docFeatureBuilder);

	}


	public static Ranker getRanker(String name) {

		return ffanRankerV1;
	}


}
