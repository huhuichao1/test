package com.wanda.feeds.ranker.access;


import com.wanda.feeds.common.entity.base.RecordBase;
import com.wanda.feeds.common.utils.callback.SQLCallback;
import com.wanda.feeds.dataaccess.record.DocumentRecord;
import com.wanda.feeds.ranker.processer.NormDataProcesser;
import com.wanda.feeds.ranker.rankers.builder.IFeatureBuilder;

public class NormDataCallback implements SQLCallback {

	IFeatureBuilder buidler;

	public Object callback(RecordBase entity) {

		DocumentRecord record = (DocumentRecord) entity;
		DocWithFeature doc = buidler.buildFeature(record);
		NormDataProcesser.putRankFeature(record.getId(), doc);
		// TODO Auto-generated method stub
		return null;
	}

	public NormDataCallback(IFeatureBuilder buidler) {
		this.buidler = buidler;

	}

}
