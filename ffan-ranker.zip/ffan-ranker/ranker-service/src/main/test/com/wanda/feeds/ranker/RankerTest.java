package com.wanda.feeds.ranker;


import com.wanda.feeds.common.entity.*;
import com.wanda.feeds.common.entity.base.KeyValuePair;
import com.wanda.feeds.ranker.rankers.base.RankerFactory;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huhuichao on 2017/8/15.
 */
public class RankerTest {


    @Test
    public void nlpRanker() throws Exception {
        FilterSet filterSet = buildNLPFilterSet();
        UserProfile profile=buildNLPUserProfile();
        DocumentSet set = RankerFactory.getRanker("nlpRanker").ranking(filterSet, profile);
        for (RankRecord r : set.getRecords()) {
            System.out.println(r);
        }
    }

    @Test
    public void nlpRankerV1() throws Exception {
        FilterSet filterSet = buildNLPFilterSet();
        UserProfile profile=buildNLPUserProfile();
        DocumentSet set = RankerFactory.getRanker("nlpRankerV1").ranking(filterSet, profile);
        for (RankRecord r : set.getRecords()) {
            System.out.println(r);
        }
    }


    @Test
    public void timeRanker() throws Exception {
        FilterSet filterSet = new FilterSet();
        List<DocNLPRecord> list = new ArrayList<DocNLPRecord>();
        DocNLPRecord record = new DocNLPRecord();
        record.setId("0");
        // frecord.setUpdateTime(1472745600000l);
        // frecord.setId("b");
        list.add(record); // OR filterSet.addRecord(frecord);
        record = new DocNLPRecord();
        record.setId("27690531681206272");
        // frecord.setUpdateTime(1472745600000l);
        // frecord.setId("b");
        list.add(record);
        record = new DocNLPRecord();
        record.setId("27785277133029376");
        // frecord.setUpdateTime(1472745600000l);
        // frecord.setId("b");
        list.add(record);
        filterSet.setNLPRecords(list);

        UserProfile profile = new UserProfile();

        DocumentSet set = RankerFactory.getRanker("timeRanker").ranking(filterSet, profile);
        for (RankRecord r : set.getRecords()) {
            System.out.println(r);
        }
    }

    public static UserProfile buildNLPUserProfile(){

        UserProfile profile = new UserProfile();
        List<KeyValuePair> topic64=new ArrayList<>();
        List<KeyValuePair> keywords=new ArrayList<>();
        List<KeyValuePair> category=new ArrayList<>();

        topic64=new ArrayList<>();
        topic64.add(new KeyValuePair("2", 0.054205246913580245));
        topic64.add(new KeyValuePair("5", 0.20852623456790123));
        topic64.add(new KeyValuePair("60", 0.029513888888888888));
        topic64.add(new KeyValuePair("64", 0.24205246913580245));
        keywords=new ArrayList<>();
        keywords.add(new KeyValuePair("搞笑", 1d));
        keywords.add(new KeyValuePair("衣服", 1d));
        keywords.add(new KeyValuePair("棉花", 1d));
        keywords.add(new KeyValuePair("汽车", 1d));
        category=new ArrayList<>();
        category.add(new KeyValuePair("156", 1d));
        category.add(new KeyValuePair("101", 1d));
        category.add(new KeyValuePair("102", 1d));
        profile.setTopic64Preference(topic64);
        profile.setKeywordPreference(keywords);
        profile.setCategoryPreference(category);
        return profile;
    }

    /**
     * 组装nlp测试数据
     * @return
     */
    public static FilterSet buildNLPFilterSet(){
        FilterSet filterSet = new FilterSet();
        List<DocNLPRecord> list = new ArrayList<DocNLPRecord>();
        DocNLPRecord record = new DocNLPRecord();
        record.setId("0");
        // frecord.setUpdateTime(1472745600000l);
        // frecord.setId("b");
        list.add(record); // OR filterSet.addRecord(frecord);
        record = new DocNLPRecord();
        record.setId("27690531681206272");
        // frecord.setUpdateTime(1472745600000l);
        // frecord.setId("b");
        list.add(record);
        record = new DocNLPRecord();
        record.setId("27785277133029376");
        // frecord.setUpdateTime(1472745600000l);
        // frecord.setId("b");
        list.add(record);
        filterSet.setNLPRecords(list);
        return filterSet;
    }
}
