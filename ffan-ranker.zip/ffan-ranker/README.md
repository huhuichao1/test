# rankers
基于注册机制的RPC 热插拔ranker系统架构，提供L2排序服务。


## 系统模块

### 模块介绍

#### storeRankerV1

- 初版。一个线性模型


### 类图

#### storeRankerV1

![输入图片说明](https://ws2.sinaimg.cn/large/006tNc79ly1fgqiarcndqj30o70l4409.jpg "在这里输入图片标题")



## 开发工具:
- 开发IDE: IntelliJ IDEA ／ Eclipse


## 开发环境：
- JDk1.8



